@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

REM Na primeira vez pergunta o IP da TV e guarda em ip.txt. Depois e so dar duplo clique.
if not exist ip.txt (
  set /p TV_IP=Digite o IP da TV ^(Developer Mode App^): 
  >ip.txt echo %TV_IP%
)
set /p TV_IP=<ip.txt

where ares-package >nul 2>nul
if errorlevel 1 (
  echo Instalando o ares-cli ^(so na primeira vez^)...
  call npm install -g @webos-tools/cli || (echo Instale o Node.js em nodejs.org e rode de novo. & pause & exit /b 1)
)

call ares-setup-device --add tv -i "host=%TV_IP%" -i "port=9922" -i "username=prisoner" >nul 2>nul
call ares-setup-device --modify tv -i "host=%TV_IP%" >nul 2>nul

if exist build rmdir /s /q build
mkdir build
call ares-package launcher -o build || goto erro
for %%f in (build\*.ipk) do set IPK=%%f
call ares-install --device tv "%IPK%" || goto erro
call ares-launch --device tv com.meu.launcher || goto erro
echo.
echo Pronto! Launcher atualizado na TV.
timeout /t 3 >nul
exit /b 0

:erro
echo.
echo Algo falhou. Confira: TV ligada, Developer Mode ativo, "Key Server" ligado, IP certo.
echo Para trocar o IP, apague o arquivo ip.txt e rode de novo.
echo Se pedir a chave: ares-novacom --device tv --getkey  (senha = a do Dev Mode App)
pause
exit /b 1
