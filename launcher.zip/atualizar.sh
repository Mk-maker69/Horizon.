#!/usr/bin/env bash
# Uso: ./atualizar.sh [IP_DA_TV]  (o IP fica guardado em ip.txt; nas proximas vezes nao precisa digitar)
cd "$(dirname "$0")"
[ -n "$1" ] && echo "$1" > ip.txt
[ -f ip.txt ] || { read -rp "IP da TV: " ip; echo "$ip" > ip.txt; }
TV_IP="$(cat ip.txt)"

command -v ares-package >/dev/null || npm install -g @webos-tools/cli || exit 1
ares-setup-device --add tv -i "host=$TV_IP" -i "port=9922" -i "username=prisoner" 2>/dev/null \
  || ares-setup-device --modify tv -i "host=$TV_IP"

rm -rf build && mkdir build
ares-package launcher -o build &&
ares-install --device tv build/*.ipk &&
ares-launch --device tv com.meu.launcher &&
echo "Pronto! Launcher atualizado na TV."
