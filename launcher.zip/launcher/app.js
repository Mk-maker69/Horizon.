// ---- QR code (byte mode, correcao L, versoes 1-10). Sem bibliotecas. ----
var HZQR = (function () {
  var EXP = [], LOG = [], i, x = 1;
  for (i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 285; }
  for (i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
  function mul(a, b) { return a && b ? EXP[LOG[a] + LOG[b]] : 0; }
  function rs(data, n) {                       // codigos de correcao de erro Reed-Solomon
    var g = [1], j, k;
    for (j = 0; j < n; j++) {
      var ng = [];
      for (k = 0; k <= g.length; k++) ng[k] = (g[k] || 0) ^ mul(g[k - 1] || 0, EXP[j]);
      g = ng;
    }
    var r = [];
    for (j = 0; j < n; j++) r[j] = 0;
    for (j = 0; j < data.length; j++) {
      var f = data[j] ^ r[0];
      r.shift(); r.push(0);
      for (k = 0; k < n; k++) r[k] ^= mul(g[k + 1], f);
    }
    return r;
  }
  // por versao: [ec por bloco, blocos grupo1, dados grupo1, blocos grupo2, dados grupo2]
  var VER = [null, [7,1,19,0,0],[10,1,34,0,0],[15,1,55,0,0],[20,1,80,0,0],[26,1,108,0,0],[18,2,68,0,0],[20,2,78,0,0],[24,2,97,0,0],[30,2,116,0,0],[18,2,68,2,69]];
  var ALIGN = [null, [], [6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50]];
  function bch(v, poly, bits) {
    var d = v << bits, p = poly, ph = 0, t = poly;
    while (t >> (ph + 1)) ph++;
    for (var s = 31; s >= ph; s--) if ((d >> s) & 1) d ^= poly << (s - ph);
    return (v << bits) | d;
  }
  function make(text) {
    var bytes = [];
    var u = unescape(encodeURIComponent(text));
    for (i = 0; i < u.length; i++) bytes.push(u.charCodeAt(i));
    var ver = 0, tot;
    for (var v = 1; v <= 10; v++) {
      var V = VER[v]; tot = V[1] * V[2] + V[3] * V[4];
      if (bytes.length + (v < 10 ? 2 : 3) <= tot) { ver = v; break; }
    }
    if (!ver) return null;
    var V = VER[ver]; tot = V[1] * V[2] + V[3] * V[4];
    var bits = [];
    function put(val, n) { for (var b = n - 1; b >= 0; b--) bits.push((val >> b) & 1); }
    put(4, 4); put(bytes.length, ver < 10 ? 8 : 16);
    for (i = 0; i < bytes.length; i++) put(bytes[i], 8);
    for (i = 0; i < 4 && bits.length < tot * 8; i++) bits.push(0);
    while (bits.length % 8) bits.push(0);
    var cw = [];
    for (i = 0; i < bits.length; i += 8) { var by = 0; for (var q = 0; q < 8; q++) by = by * 2 + bits[i + q]; cw.push(by); }
    for (i = 0; cw.length < tot; i++) cw.push(i % 2 ? 17 : 236);
    var blocks = [], pos = 0, bi;
    for (bi = 0; bi < V[1] + V[3]; bi++) {
      var len = bi < V[1] ? V[2] : V[4];
      var d = cw.slice(pos, pos + len); pos += len;
      blocks.push({ d: d, e: rs(d, V[0]) });
    }
    var fin = [], maxd = Math.max(V[2], V[4]);
    for (i = 0; i < maxd; i++) blocks.forEach(function (b) { if (i < b.d.length) fin.push(b.d[i]); });
    for (i = 0; i < V[0]; i++) blocks.forEach(function (b) { fin.push(b.e[i]); });

    var N = ver * 4 + 17, M = [], R = [];       // M = modulos, R = reservado (funcao)
    for (i = 0; i < N; i++) { M.push([]); R.push([]); }
    function set(r, c, val) { if (r >= 0 && c >= 0 && r < N && c < N) { M[r][c] = val ? 1 : 0; R[r][c] = 1; } }
    function finder(r, c) {
      for (var a = -1; a <= 7; a++) for (var b = -1; b <= 7; b++) {
        var on = a >= 0 && a <= 6 && b >= 0 && b <= 6 && (a === 0 || a === 6 || b === 0 || b === 6 || (a >= 2 && a <= 4 && b >= 2 && b <= 4));
        set(r + a, c + b, on);
      }
    }
    finder(0, 0); finder(0, N - 7); finder(N - 7, 0);
    for (i = 8; i < N - 8; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    var al = ALIGN[ver];
    al.forEach(function (r) { al.forEach(function (c) {
      if ((r === 6 && c === 6) || (r === 6 && c === al[al.length - 1]) || (c === 6 && r === al[al.length - 1])) return;
      for (var a = -2; a <= 2; a++) for (var b = -2; b <= 2; b++) set(r + a, c + b, Math.max(Math.abs(a), Math.abs(b)) !== 1);
    }); });
    set(N - 8, 8, 1);                            // modulo escuro fixo
    for (i = 0; i < 9; i++) { if (!R[8][i]) set(8, i, 0); if (!R[i][8]) set(i, 8, 0); }
    for (i = 0; i < 8; i++) { if (!R[8][N - 1 - i]) set(8, N - 1 - i, 0); if (!R[N - 1 - i][8]) set(N - 1 - i, 8, 0); }
    if (ver >= 7) for (i = 0; i < 6; i++) for (var j2 = 0; j2 < 3; j2++) { set(i, N - 11 + j2, 0); set(N - 11 + j2, i, 0); }
    // dados em zigue-zague
    var all = [];
    fin.forEach(function (b) { for (var s = 7; s >= 0; s--) all.push((b >> s) & 1); });
    var rem = ver >= 2 && ver <= 6 ? 7 : 0; while (rem--) all.push(0);
    var bit = 0, up = true, col;
    var DATA = []; for (i = 0; i < N; i++) DATA.push([]);
    for (col = N - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      for (var t = 0; t < N; t++) {
        var rr = up ? N - 1 - t : t;
        for (var cc = 0; cc < 2; cc++) {
          var c2 = col - cc;
          if (!R[rr][c2]) { DATA[rr][c2] = bit < all.length ? all[bit] : 0; bit++; }
        }
      }
      up = !up;
    }
    var MASK = [
      function (r, c) { return (r + c) % 2 === 0; }, function (r) { return r % 2 === 0; },
      function (r, c) { return c % 3 === 0; }, function (r, c) { return (r + c) % 3 === 0; },
      function (r, c) { return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0; },
      function (r, c) { return (r * c) % 2 + (r * c) % 3 === 0; },
      function (r, c) { return ((r * c) % 2 + (r * c) % 3) % 2 === 0; },
      function (r, c) { return ((r + c) % 2 + (r * c) % 3) % 2 === 0; }
    ];
    function build(mk) {
      var G = [], r, c;
      for (r = 0; r < N; r++) { G.push([]); for (c = 0; c < N; c++) G[r][c] = R[r][c] ? M[r][c] : (DATA[r][c] ^ (MASK[mk](r, c) ? 1 : 0)); }
      var f = bch((1 << 3) | mk, 0x537, 10) ^ 0x5412;       // correcao L = 01
      for (i = 0; i < 15; i++) {
        var b = (f >> i) & 1;
        if (i < 6) G[i][8] = b; else if (i < 8) G[i + 1][8] = b; else G[N - 15 + i][8] = b;
        if (i < 8) G[8][N - 1 - i] = b; else if (i < 9) G[8][15 - i] = b; else G[8][14 - i] = b;
      }
      G[N - 8][8] = 1;
      if (ver >= 7) {
        var vi = bch(ver, 0x1f25, 12);
        for (i = 0; i < 18; i++) { var vb = (vi >> i) & 1; G[Math.floor(i / 3)][N - 11 + (i % 3)] = vb; G[N - 11 + (i % 3)][Math.floor(i / 3)] = vb; }
      }
      return G;
    }
    function penalty(G) {
      var p = 0, r, c, run, dark = 0;
      for (var o = 0; o < 2; o++) for (r = 0; r < N; r++) {
        run = 1;
        for (c = 1; c < N; c++) {
          var a = o ? G[c][r] : G[r][c], b = o ? G[c - 1][r] : G[r][c - 1];
          if (a === b) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1;
        }
      }
      for (r = 0; r < N - 1; r++) for (c = 0; c < N - 1; c++) if (G[r][c] === G[r][c + 1] && G[r][c] === G[r + 1][c] && G[r][c] === G[r + 1][c + 1]) p += 3;
      var pat = [1,0,1,1,1,0,1,0,0,0,0], pat2 = pat.slice().reverse();
      for (var o2 = 0; o2 < 2; o2++) for (r = 0; r < N; r++) for (c = 0; c <= N - 11; c++) {
        var m1 = true, m2 = true;
        for (var k = 0; k < 11; k++) { var vv = o2 ? G[c + k][r] : G[r][c + k]; if (vv !== pat[k]) m1 = false; if (vv !== pat2[k]) m2 = false; }
        if (m1) p += 40; if (m2) p += 40;
      }
      for (r = 0; r < N; r++) for (c = 0; c < N; c++) dark += G[r][c];
      p += Math.floor(Math.abs(dark * 100 / (N * N) - 50) / 5) * 10;
      return p;
    }
    var best = null, bp = 1e9;
    for (var mk = 0; mk < 8; mk++) { var g = build(mk), pp = penalty(g); if (pp < bp) { bp = pp; best = g; } }
    return best;
  }
  // SVG pronto: modulos pretos sobre fundo branco com margem de 3 modulos
  function svg(text) {
    var G = make(text);
    if (!G) return "";
    var N = G.length, q = 3, d = "", r, c;
    for (r = 0; r < N; r++) for (c = 0; c < N; c++) if (G[r][c]) d += "M" + (c + q) + " " + (r + q) + "h1v1h-1z";
    var s = N + q * 2;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + s + " " + s + '" shape-rendering="crispEdges"><rect width="' + s + '" height="' + s + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
  }
  return { make: make, svg: svg };
})();

// ============================================================
// LISTA DE APPS - edite aqui para trocar, adicionar ou remover.
// id     = ID do app na TV (se estiver errado, o launcher acha pelo nome).
// titles = nomes que o app tem na TV (minusculo) - usado para achar o icone real.
// hints  = pedacos do ID, caso nem o ID nem o nome batam.
// url    = abre no navegador da TV.
// a/b    = cores do degrade do icone (so aparece se nao achar o icone real).
// ============================================================
var ICON = {
  play:  '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="#fff"/></svg>',
  music: '<svg viewBox="0 0 24 24"><path fill="#fff" d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3z"/></svg>',
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/></svg>',
  input: '<svg viewBox="0 0 24 24"><path fill="#fff" d="M21 3H3v6h2V5h14v14h-6v2h8V3zM11 16l4-4-4-4v3H3v2h8z"/></svg>',
  grid:  '<svg viewBox="0 0 24 24" fill="#fff"><rect x="3" y="3" width="8" height="8" rx="2.2"/><rect x="13" y="3" width="8" height="8" rx="2.2"/><rect x="3" y="13" width="8" height="8" rx="2.2"/><rect x="13" y="13" width="8" height="8" rx="2.2"/></svg>',
  tv:    '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="12" rx="2.2"/><path d="M8 21h8M12 17v4"/></svg>',
  gear:  '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="3.4"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1"/></svg>'
};

var CATALOG = [
  { name: "Netflix",       id: "netflix",             titles: ["netflix"],                                  hints: ["netflix"],
    a: "#ff4b52", b: "#8e0b12", glow: "rgba(229,9,20,.55)",   letter: "N" },
  { name: "YouTube",       id: "youtube.leanback.v4", titles: ["youtube"],                                  hints: ["youtube.leanback"],
    a: "#ff5a5a", b: "#b3001b", glow: "rgba(255,40,40,.5)",   icon: "play" },
  { name: "Prime Video",   id: "amazon",              titles: ["prime video", "amazon prime video"],        hints: ["amazon"],
    a: "#3bb5ff", b: "#1456c8", glow: "rgba(40,140,255,.5)",  letter: "P" },
  { name: "Globoplay",     id: "globoplaytv",         titles: ["globoplay"],                                hints: ["globo"],
    a: "#ff9a4a", b: "#e0381f", glow: "rgba(255,110,40,.5)",  letter: "G" },
  { name: "YouTube Music", url: "https://music.youtube.com", titles: ["youtube music"], hints: [],
    a: "#ff6a8a", b: "#8a1fb0", glow: "rgba(200,50,160,.5)", icon: "music" },

  { name: "Disney+",       id: "com.disney.disneyplus-prod", titles: ["disney+", "disney plus"],            hints: ["disney"],
    a: "#5b86ff", b: "#1b2a8a", glow: "rgba(60,100,255,.5)", letter: "D" },
  { name: "Spotify",       id: "spotify-beehive",     titles: ["spotify"],                                  hints: ["spotify"],
    a: "#46e08a", b: "#0f8a45", glow: "rgba(40,210,120,.45)", letter: "S" },
  { name: "Navegador",     id: "com.webos.app.browser",     a: "#8a98c4", b: "#2f3b5e", glow: "rgba(120,140,200,.45)", icon: "globe" },
  { name: "Entradas",      id: "com.webos.app.inputpicker", a: "#62d8cf", b: "#1e7f86", glow: "rgba(60,200,200,.45)",  icon: "input" },
  { name: "Todos os apps", id: "com.webos.app.home",        a: "#c3b0ff", b: "#5b6bd6", glow: "rgba(150,130,255,.5)",  icon: "grid" },

  // ---- extras: aparecem em "Organizar" para adicionar na tela inicial ----
  // (se o app estiver instalado na TV o launcher abre ele; senao abre o site no navegador)
  { name: "Max",           url: "https://play.max.com",          titles: ["max", "hbo max"],            hints: ["hbomax"],
    a: "#8b5cff", b: "#2a1470", glow: "rgba(120,80,255,.5)",  letter: "M" },
  { name: "Apple TV",      url: "https://tv.apple.com",          titles: ["apple tv", "apple tv+"],     hints: ["appletv", "apple.tv"],
    a: "#7a7f8c", b: "#14161c", glow: "rgba(150,155,170,.4)", letter: "A" },
  { name: "Paramount+",    url: "https://www.paramountplus.com", titles: ["paramount+", "paramount plus"], hints: ["paramount"],
    a: "#4f8dff", b: "#0b2f9a", glow: "rgba(60,120,255,.5)",  letter: "P" },
  { name: "Crunchyroll",   url: "https://www.crunchyroll.com",   titles: ["crunchyroll"],               hints: ["crunchyroll"],
    a: "#ffa24a", b: "#d9560b", glow: "rgba(255,130,40,.5)",  letter: "C" },
  { name: "Twitch",        url: "https://www.twitch.tv",         titles: ["twitch"],                    hints: ["twitch"],
    a: "#a970ff", b: "#4a1fa8", glow: "rgba(150,90,255,.5)",  letter: "T" },
  { name: "Pluto TV",      url: "https://pluto.tv",              titles: ["pluto tv"],                  hints: ["pluto"],
    a: "#ffe14a", b: "#c99a00", glow: "rgba(255,210,60,.45)", letter: "P" },
  { name: "Deezer",        url: "https://www.deezer.com",        titles: ["deezer"],                    hints: ["deezer"],
    a: "#ff6a8a", b: "#9a1f66", glow: "rgba(230,60,130,.5)",  icon: "music" },
  { name: "Plex",          url: "https://app.plex.tv",           titles: ["plex"],                      hints: ["plex"],
    a: "#ffc24a", b: "#b56b00", glow: "rgba(255,180,50,.5)",  icon: "play" },
  { name: "TV ao vivo",    id: "com.webos.app.livetv",          a: "#59c7ff", b: "#1e5fa8", glow: "rgba(60,160,255,.5)",  icon: "tv" },
  { name: "Config. da TV", id: "com.palm.app.settings",         a: "#9aa4bd", b: "#3a4260", glow: "rgba(140,150,190,.45)", icon: "gear" }
];

var APPS = [];                     // os que estao na tela inicial, na ordem (vem de CATALOG)

// ============================================================
// VISUAIS (vem do Horizon). sw = cor da amostra no menu.
// ============================================================
var STYLES = [
  { key: "glass",    name: "Vidro",    sw: "linear-gradient(135deg,#1c3f8f,#5b3fa8 55%,#12808a)" },
  { key: "aero",     name: "Aero",     sw: "linear-gradient(180deg,#041a38,#0a4a7a 55%,#1d7a52)" },
  { key: "y2k",      name: "Y2K",      sw: "linear-gradient(135deg,#0d0833,#6a3fd0 55%,#ff5fd2)" },
  { key: "luxury",   name: "Luxo",     sw: "linear-gradient(135deg,#0a0807,#2c2319 55%,#c9a24a)" },
  { key: "stortrix", name: "Terminal", sw: "linear-gradient(135deg,#000,#03200d 55%,#00ff66)" },
  { key: "simple",   name: "Simples",  sw: "linear-gradient(135deg,#101a30,#17233f 55%,#6aa8ff)" }
];

// ============================================================
// LIFESTYLES: cada um tem seu proprio layout e sua propria lista de apps.
// O VISUAL (Vidro, Aero...) so troca cores/fontes/formas e vale para todos.
//   basic = grade de apps + lista de noticias
//   cyber = estilo console: abas Inicio / Noticias / Entradas, fundo segue o app
// ============================================================
var LIFE = {
  basic: { name: "Basic", desc: "Grade de apps + lista de notícias", max: 15, key: "hz_apps",
           sw: "linear-gradient(135deg,#101a30,#2a4aa0)",
           def: ["Netflix", "YouTube", "Prime Video", "Globoplay", "YouTube Music", "Disney+", "Spotify", "Navegador", "Entradas", "Todos os apps"] },
  cyber: { name: "Cyber", desc: "Estilo console · fundo muda com o app", max: 10, key: "hz_apps_cyber",
           sw: "linear-gradient(135deg,#05070f,#7a0c18 60%,#ff3b4a)",
           def: ["Netflix", "YouTube", "Prime Video", "Globoplay", "Spotify", "Disney+", "Navegador"] }
};
var LIFE_KEYS = ["basic", "cyber"];
function maxApps() { return LIFE[life].max; }

// noticias reais (veja o bloco NOTICIAS REAIS mais abaixo)
var NEWS = [];
var INPUTS = [
  { name: "HDMI 1",    id: "com.webos.app.hdmi1",  a: "#ff8a1f", b: "#d8402f" },
  { name: "HDMI 2",    id: "com.webos.app.hdmi2",  a: "#ff8a1f", b: "#d8402f" },
  { name: "TV ao vivo", id: "com.webos.app.livetv", a: "#59c7ff", b: "#1e5fa8" }
];

// ============================================================
// ESTADO
// ============================================================
var COLS = 5;                 // colunas da grade (Basic e Organizar)
var index = 0;                // app em foco (na lista do lifestyle atual)
var cells = [];
var focusEl = null;
var life = "basic", savedLife = "basic";
var showNews = true;
var screen = "home";          // tela que recebe as teclas: home | settings | picker | org
var stack = [];               // telas por baixo da atual (ex.: Configuracoes -> Visual)
var zone = "content";         // na home: "content", "header" ou "news" (lista de noticias do Basic)
var hdrIndex = 0;             // posicao na barra do topo (abas + icones)
var cyTab = "home";           // Cyber: home | news | inputs
var cyRow = 0;                // Cyber/Inicio: 0 = apps, 1 = cartoes
var cardIdx = 0, newsIdx = 0, inIdx = 0;
var bnIdx = 0, bnTop = 0, BN_VIS = 4;   // Basic: item em foco e janela de itens da lista de noticias
var bootAt = Date.now();
var introDone = false;
var introStart = Date.now();
var introTimer = null;
var savedStyle = "glass";
var introOn = true;
var theme = "default";        // "default" ou "dark"
var perf = "normal";          // "normal" ou "lite"

function $(id) { return document.getElementById(id); }

// ---------- guardar preferencias ----------
function store(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function recall(k, d) {
  try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; }
}

function validStyle(k) {
  for (var i = 0; i < STYLES.length; i++) if (STYLES[i].key === k) return true;
  return false;
}
function applyStyle(k) { document.documentElement.setAttribute("data-style", k); }
function applyTheme() { document.documentElement.setAttribute("data-theme", theme); }
function toggleTheme() {
  theme = theme === "dark" ? "default" : "dark";
  store("hz_theme", theme);
  applyTheme(); refreshRows();
}

// ============================================================
// NAVEGACAO - uma pilha de telas e UM unico tratador de teclas.
//   push("settings") abre por cima; pop() volta para a anterior.
//   Voltar sempre sobe um nivel: picker/org -> (config) -> home -> sai.
// ============================================================
function push(s) { stack.push(screen); screen = s; renderScreens(); }
function pop() { screen = stack.length ? stack.pop() : "home"; renderScreens(); }
function renderScreens() {
  var all = stack.concat([screen]);
  $("vmenu").classList.toggle("open", screen === "picker");
  $("omenu").classList.toggle("open", screen === "org");
  $("reader").classList.toggle("open", screen === "reader");
  $("prompt").classList.toggle("open", screen === "prompt");
  document.body.classList.toggle("tab-settings", all.indexOf("settings") >= 0);
  refreshFocus();
}
function canPoint() { return introDone && screen === "home"; }

// fecha tudo e volta para a home (usado ao voltar do app / ver animacao)
function closeAll() {
  if (pk) { var p = pk; pk = null; p.preview(p.cur()); }
  if (orgOpen) { orgOpen = false; oMode = "nav"; if (oDirty) APPS = oBackup.slice(); oDirty = false; }
  stack = []; screen = "home";
  renderScreens(); refreshFocus();
}

// ---------- barra do topo: [abas (Cyber)] + [Organizar, Lifestyle, Visual, Config.] ----------
var TOOLS = [
  { id: "obtn", act: function () { openOrg(); } },
  { id: "lbtn", act: function () { openLife(); } },
  { id: "vbtn", act: function () { openVisual(); } },
  { id: "sbtn", act: function () { openSettings(); } }
];
var TAB_NAME = { home: "Início", news: "Notícias", inputs: "Entradas" };
function tabList() { return showNews ? ["home", "news", "inputs"] : ["home", "inputs"]; }

function hdrItems() {
  var l = [];
  if (life === "cyber") tabList().forEach(function (t) { l.push({ el: $("tab-" + t), tab: t }); });
  TOOLS.forEach(function (t) { l.push({ el: $(t.id), act: t.act }); });
  return l;
}
function hdrFind(el) {
  var L = hdrItems();
  for (var i = 0; i < L.length; i++) if (L[i].el === el) return i;
  return -1;
}
function hdrAt(i) {
  var L = hdrItems();
  if (i < 0 || i >= L.length) return;
  hdrIndex = i;
  if (L[i].tab) setTab(L[i].tab);          // abas trocam ao receber o foco
  else refreshFocus();
}
function hdrOK() {
  var it = hdrItems()[hdrIndex];
  if (!it) return;
  if (it.tab) { zone = "content"; refreshFocus(); }
  else if (it.act) it.act();
}
function wireHdr(el) {
  el.addEventListener("mouseenter", function () {
    if (!canPoint()) return;
    var i = hdrFind(el);
    if (i >= 0 && !(zone === "header" && hdrIndex === i)) { zone = "header"; hdrAt(i); }
  });
  el.addEventListener("click", function () {
    if (!canPoint()) return;
    var i = hdrFind(el);
    if (i >= 0) { zone = "header"; hdrAt(i); hdrOK(); }
  });
}
function buildTabs() {
  var box = $("tabs");
  box.innerHTML = "";
  tabList().forEach(function (t) {
    var d = document.createElement("div");
    d.className = "tab"; d.id = "tab-" + t; d.textContent = TAB_NAME[t];
    box.appendChild(d);
    wireHdr(d);
  });
}
function setTab(t) {
  cyTab = t; cyRow = 0;
  $("cyber").setAttribute("data-tab", t);
  refreshFocus();
}
function toHeader() {
  zone = "header";
  hdrIndex = life === "cyber" ? Math.max(0, tabList().indexOf(cyTab)) : 0;
  refreshFocus();
}

// ---------- apps (grade no Basic, fileira no Cyber) ----------
function gridEl() { return life === "cyber" ? $("crow") : $("grid"); }

function buildCells() {
  $("grid").innerHTML = ""; $("crow").innerHTML = "";
  var grid = gridEl();
  cells = []; focusEl = null; applied = {};
  $("grid").className = "grid" + (APPS.length > 10 ? " dense" : "");
  var frag = document.createDocumentFragment();
  APPS.forEach(function (app, i) {
    var cell = document.createElement("div");
    cell.className = "app";
    cell.style.setProperty("--n", i);
    cell.style.setProperty("--a", app.a);
    cell.style.setProperty("--b", app.b);
    cell.style.setProperty("--glow", app.glow);

    var ico = document.createElement("div");
    ico.className = "ico";
    ico.innerHTML = app.icon ? ICON[app.icon] : '<span class="lt">' + app.letter + "</span>";

    var name = document.createElement("div");
    name.className = "name";
    name.textContent = app.name;

    cell.appendChild(ico);
    cell.appendChild(name);
    frag.appendChild(cell);
    cell._ico = ico;
    cells.push(cell);

    // Magic Remote (ponteiro)
    cell.addEventListener("mouseenter", function () { if (canPoint()) setFocus(i); });
    cell.addEventListener("click", function () { if (canPoint()) { setFocus(i); launchCur(); } });
  });
  grid.appendChild(frag);
  for (var q = 0; q < APPS.length; q++) if (iconCache[APPS[q].name]) applyImage(q, iconCache[APPS[q].name]);
}
function buildGrid() { buildCells(); refreshFocus(); }
function rebuildGrid() {
  if (index > APPS.length - 1) index = APPS.length - 1;
  if (index < 0) index = 0;
  buildCells(); refreshFocus();
}
function setFocus(i) {
  if (i < 0 || i >= APPS.length) return;
  index = i; zone = "content"; cyRow = 0;
  refreshFocus();
}

// ---------- Cyber: cartoes, noticias, entradas ----------
function cardList() { return showNews ? ["cont", "news", "inp"] : ["cont", "inp"]; }

function mkCard(cls, eyebrow, title, sub) {
  var d = document.createElement("div");
  d.className = cls;
  d.innerHTML = '<div class="ceye"></div><div class="ctit"></div><div class="csb"></div>';
  d.childNodes[0].textContent = eyebrow;
  d.childNodes[1].textContent = title;
  d.childNodes[2].textContent = sub;
  return d;
}
function buildCyber() {
  var cc = $("ccards"), nc = $("ncards"), ic = $("icards");
  cc.innerHTML = ""; nc.innerHTML = ""; ic.innerHTML = "";
  var last = recall("hz_last", "");
  cardList().forEach(function (id, j) {
    var d;
    if (id === "cont") d = mkCard("ccard", "CONTINUAR", "Última reprodução", last ? last + " · retomar de onde parou" : "Abra um app para começar");
    else if (id === "news") d = NEWS.length ? mkCard("ccard", "NOTÍCIAS", NEWS[0].t, newsSub(NEWS[0])) : mkCard("ccard", "NOTÍCIAS", newsMsg(), "Abra a aba Notícias");
    else d = mkCard("ccard", "ENTRADAS", "HDMI 1 · HDMI 2", "TV ao vivo");
    d.addEventListener("mouseenter", function () { if (canPoint() && life === "cyber") { zone = "content"; cyRow = 1; cardIdx = j; refreshFocus(); } });
    d.addEventListener("click", function () { if (canPoint() && life === "cyber") { cardIdx = j; cardOK(); } });
    cc.appendChild(d);
  });
  if (!NEWS.length) {
    var e = mkCard("ncard", "NOTÍCIAS", newsMsg(), "Config. › Atualização › Atualizar notícias");
    e.insertBefore(document.createElement("div"), e.firstChild).className = "art";
    e.firstChild.style.background = "linear-gradient(135deg,#59c7ff,#1e5fa8)";
    nc.appendChild(e);
  }
  NEWS.forEach(function (n, j) {
    var d = mkCard("ncard", n.cat.toUpperCase(), n.t, newsSub(n));
    d.insertBefore(document.createElement("div"), d.firstChild).className = "art";
    d.firstChild.style.backgroundImage = artBg(n);
    d.addEventListener("mouseenter", function () { if (canPoint() && cyTab === "news") { zone = "content"; newsIdx = j; refreshFocus(); } });
    d.addEventListener("click", function () { if (canPoint() && cyTab === "news") { newsIdx = j; openReader(j); } });
    nc.appendChild(d);
  });
  INPUTS.forEach(function (n, j) {
    var d = mkCard("ncard inp", "ENTRADA", n.name, "OK para abrir");
    d.insertBefore(document.createElement("div"), d.firstChild).className = "art";
    d.firstChild.style.background = "linear-gradient(135deg," + n.a + "," + n.b + ")";
    d.addEventListener("mouseenter", function () { if (canPoint() && cyTab === "inputs") { zone = "content"; inIdx = j; refreshFocus(); } });
    d.addEventListener("click", function () { if (canPoint() && cyTab === "inputs") { inIdx = j; launchApp(INPUTS[j]); } });
    ic.appendChild(d);
  });
}
function cardOK() {
  var id = cardList()[cardIdx];
  if (id === "cont") {
    var nm = recall("hz_last", ""), app = APPS[index];
    for (var i = 0; i < APPS.length; i++) if (APPS[i].name === nm) app = APPS[i];
    if (app) launchApp(app);
  } else if (id === "news") { setTab("news"); zone = "content"; refreshFocus(); }
  else { setTab("inputs"); zone = "content"; refreshFocus(); }
}

// notícias ligadas/desligadas (Basic: painel ao lado; Cyber: aba + cartao)
function applyNews() {
  document.body.classList.toggle("news-on", showNews);
  if (tabList().indexOf(cyTab) < 0) cyTab = "home";
  $("cyber").setAttribute("data-tab", cyTab);
  buildTabs(); buildCyber();
  var n = hdrItems().length;
  if (hdrIndex > n - 1) hdrIndex = n - 1;
  if (cardIdx > cardList().length - 1) cardIdx = 0;
  refreshFocus();
}
function toggleNews() {
  showNews = !showNews;
  store("hz_news", showNews ? "1" : "0");
  applyNews(); refreshRows();
}
function buildNewsPanel() {
  var box = $("nlist");
  box.innerHTML = "";
  $("nstat").textContent = newsStatus();
  if (!NEWS.length) {
    var m = document.createElement("div");
    m.className = "nitem nmsg";
    m.textContent = newsMsg();
    box.appendChild(m);
    return;
  }
  if (bnIdx > NEWS.length - 1) bnIdx = NEWS.length - 1;
  if (bnTop > bnIdx) bnTop = bnIdx;
  if (bnIdx >= bnTop + BN_VIS) bnTop = bnIdx - BN_VIS + 1;
  for (var j = bnTop; j < Math.min(NEWS.length, bnTop + BN_VIS); j++) (function (j) {
    var n = NEWS[j], d = document.createElement("div");
    d.className = "nitem";
    d.innerHTML = '<i class="nth"></i><div class="ntx"><div class="ncat"></div><div class="nt"></div><div class="ns"></div></div>';
    d.firstChild.style.backgroundImage = artBg(n);
    d.childNodes[1].childNodes[0].textContent = n.cat.toUpperCase();
    d.childNodes[1].childNodes[1].textContent = n.t;
    d.childNodes[1].childNodes[2].textContent = newsSub(n);
    d.addEventListener("mouseenter", function () { if (canPoint() && life === "basic") { zone = "news"; bnIdx = j; refreshFocus(); } });
    d.addEventListener("click", function () { if (canPoint() && life === "basic") { bnIdx = j; openReader(j); } });
    box.appendChild(d);
  })(j);
}
function bnMove(d) {
  var n = bnIdx + d;
  if (n < 0 || n > NEWS.length - 1) return false;
  bnIdx = n;
  if (bnIdx < bnTop) bnTop = bnIdx;
  if (bnIdx >= bnTop + BN_VIS) bnTop = bnIdx - BN_VIS + 1;
  buildNewsPanel();
  return true;
}
function newsPanelKey(k) {
  if (k === 38) { if (!bnMove(-1)) toHeader(); }
  else if (k === 40) bnMove(1);
  else if (k === 37 || k === 461 || k === 27) { zone = "content"; }
  else if (k === 13) { if (NEWS.length) openReader(bnIdx); return; }
  refreshFocus();
}

// ---------- troca de lifestyle ----------
function setLife(k) {
  life = k;
  document.documentElement.setAttribute("data-life", k);
  loadLayout();
  index = 0; cyRow = 0; cyTab = "home"; zone = "content"; hdrIndex = 0;
  $("cyber").setAttribute("data-tab", "home");
  buildTabs(); buildCyber(); rebuildGrid();
}

// ---------- foco: um unico lugar pinta tudo ----------
function mark(box, idx, on) {
  var c = box.children;
  for (var i = 0; i < c.length; i++) c[i].classList.toggle("focus", on && i === idx);
}
function refreshFocus() {
  var home = screen === "home";
  var cy = life === "cyber";
  var appsOn = home && zone === "content" && (!cy || (cyTab === "home" && cyRow === 0));
  if (zone === "news" && (cy || !NEWS.length || !showNews)) zone = "content";
  var want = appsOn ? cells[index] : null;
  if (focusEl !== want) {
    if (focusEl) focusEl.classList.remove("focus");
    if (want) want.classList.add("focus");
    focusEl = want;
  }
  var L = hdrItems();
  for (var i = 0; i < L.length; i++) {
    L[i].el.classList.toggle("focus", home && zone === "header" && i === hdrIndex);
    if (L[i].tab) L[i].el.classList.toggle("on", L[i].tab === cyTab);
  }
  var inC = home && zone === "content" && cy;
  mark($("ccards"), cardIdx, inC && cyTab === "home" && cyRow === 1);
  mark($("ncards"), newsIdx, inC && cyTab === "news");
  mark($("icards"), inIdx, inC && cyTab === "inputs");
  mark($("nlist"), bnIdx - bnTop, home && zone === "news" && !cy && NEWS.length > 0);
  $("ncards").style.transform = "translate3d(" + (-Math.max(0, newsIdx - 1) * 544) + "px,0,0)";
  if (cy && APPS[index]) {                         // titulo e cor do fundo seguem o app em foco
    $("ctitle").textContent = APPS[index].name;
    document.documentElement.style.setProperty("--tint", APPS[index].glow);
  }
}

// ---------- teclas da tela inicial ----------
function headerKey(k) {
  var n = hdrItems().length;
  if (k === 37) { if (hdrIndex > 0) hdrAt(hdrIndex - 1); }
  else if (k === 39) { if (hdrIndex < n - 1) hdrAt(hdrIndex + 1); }
  else if (k === 40) { zone = "content"; refreshFocus(); }
  else if (k === 13) hdrOK();
  else if (k === 461 || k === 27) {
    if (life === "cyber" && cyTab !== "home") { setTab("home"); hdrIndex = 0; refreshFocus(); }
    else leaveApp();
  }
}
function basicKey(k) {
  var last = APPS.length - 1, lastRow = Math.floor(last / COLS), row = Math.floor(index / COLS);
  if (k === 37) { if (index % COLS > 0) setFocus(index - 1); }
  else if (k === 39) {
    if (index % COLS < COLS - 1 && index < last) setFocus(index + 1);
    else if (showNews && NEWS.length) { zone = "news"; refreshFocus(); }       // da ultima coluna para a lista de noticias
  }
  else if (k === 38) { if (row > 0) setFocus(index - COLS); else toHeader(); }
  else if (k === 40) {
    if (index + COLS <= last) setFocus(index + COLS);
    else if (row < lastRow) setFocus(last);
  }
  else if (k === 13) launchCur();
  else if (k === 461 || k === 27) leaveApp();
}
function cyberKey(k) {
  var n;
  if (cyTab === "home") {
    if (cyRow === 0) {
      if (k === 37) { if (index > 0) setFocus(index - 1); }
      else if (k === 39) { if (index < APPS.length - 1) setFocus(index + 1); }
      else if (k === 40) { cyRow = 1; refreshFocus(); }
      else if (k === 38) toHeader();
      else if (k === 13) launchCur();
      else if (k === 461 || k === 27) leaveApp();
    } else {
      n = cardList().length;
      if (k === 37) { if (cardIdx > 0) { cardIdx--; refreshFocus(); } }
      else if (k === 39) { if (cardIdx < n - 1) { cardIdx++; refreshFocus(); } }
      else if (k === 38 || k === 461 || k === 27) { cyRow = 0; refreshFocus(); }
      else if (k === 13) cardOK();
    }
    return;
  }
  var isNews = cyTab === "news";
  n = isNews ? NEWS.length : INPUTS.length;
  var cur = isNews ? newsIdx : inIdx;
  if (k === 37) cur = Math.max(0, cur - 1);
  else if (k === 39) cur = Math.max(0, Math.min(n - 1, cur + 1));
  else if (k === 38) { toHeader(); return; }
  else if (k === 13) { if (isNews) { if (NEWS.length) openReader(newsIdx); else loadNews(true); } else launchApp(INPUTS[inIdx]); return; }
  else if (k === 461 || k === 27) { setTab("home"); return; }
  if (isNews) newsIdx = cur; else inIdx = cur;
  refreshFocus();
}
function homeKey(k) {
  if (zone === "header") headerKey(k);
  else if (zone === "news" && life === "basic") newsPanelKey(k);
  else if (life === "cyber") cyberKey(k);
  else basicKey(k);
}

// ---------- abrir apps ----------
var toastTimer = null;
function toast(msg) {
  var t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.classList.remove("show"); }, 3200);
}

var bridges = [];   // guarda as chamadas ate a TV responder (senao o navegador pode descartar antes)
function luna(uri, payload, onFail, onOk) {
  try {
    var bridge = new PalmServiceBridge();
    bridges.push(bridge);
    if (bridges.length > 24) bridges.shift();
    bridge.onservicecallback = function (msg) {
      var res = {};
      try { res = JSON.parse(msg); } catch (e) {}
      if (res.returnValue === false) { if (onFail) onFail(res); }
      else if (onOk) { onOk(res); }
    };
    bridge.call(uri, JSON.stringify(payload));
  } catch (e) {
    if (onFail) onFail({ errorText: "fora da TV" });
  }
}

function launchApp(app, el) {
  if (el) { el.classList.add("press"); setTimeout(function () { el.classList.remove("press"); }, 220); }
  var id = app.rid || app.id;     // rid = ID real achado na TV pelo nome
  var payload = app.url && !app.rid
    ? { id: "com.webos.app.browser", params: { target: app.url } }
    : { id: id };
  luna("luna://com.webos.applicationManager/launch", payload, function () {
    toast(app.name + " não abriu. Aperte o botão azul para ver o diagnóstico.");
  });
  if (app.letter || app.icon) { store("hz_last", app.name); }
}
function launchCur() { if (APPS[index]) launchApp(APPS[index], cells[index]); }

// Sai do app de verdade (fecha), assim a entrada toca de novo na proxima vez
function leaveApp() {
  try { if (window.webOS && webOS.platformBack) { webOS.platformBack(); return; } } catch (e) {}
  try { window.close(); } catch (e) {}
  setTimeout(function () {
    luna("luna://com.webos.applicationManager/launch", { id: "com.webos.app.home" });
  }, 500);
}

// ============================================================
// MENU DE VISUAIS
// ============================================================
var pk = null, vcards = [], vopts = [];

// Seletor generico (Visual e Lifestyle): cartoes com previa ao vivo + opcoes embaixo.
//  cfg = { title, wide, items:[{key,name,desc,sw}], cur(), preview(key), commit(key), opts:[{label(), toggle()}] }
function openPicker(cfg) {
  pk = cfg; cfg.idx = 0; cfg.area = "cards"; cfg.oi = 0;
  for (var i = 0; i < cfg.items.length; i++) if (cfg.items[i].key === cfg.cur()) cfg.idx = i;
  $("vtitle").textContent = cfg.title;
  var box = $("vcards"); box.innerHTML = ""; vcards = [];
  box.className = "vcards" + (cfg.wide ? " wide" : "");
  cfg.items.forEach(function (s, i) {
    var c = document.createElement("div");
    c.className = "vcard";
    c.innerHTML = '<div class="vsw"></div><div class="vname"></div><div class="vdesc"></div>';
    c.childNodes[0].style.background = s.sw;
    c.childNodes[1].textContent = s.name;
    c.childNodes[2].textContent = s.desc || "";
    c.addEventListener("mouseenter", function () { if (screen === "picker") { pk.area = "cards"; pickerSet(i); } });
    c.addEventListener("click", function () { if (screen === "picker") { pickerSet(i); pickerClose(true); } });
    box.appendChild(c); vcards.push(c);
  });
  var ob = $("vopts"); ob.innerHTML = ""; vopts = [];
  (cfg.opts || []).forEach(function (o, i) {
    var d = document.createElement("div");
    d.className = "vopt";
    d.addEventListener("mouseenter", function () { if (screen === "picker") { pk.area = "opts"; pk.oi = i; pickerRefresh(); } });
    d.addEventListener("click", function () { if (screen === "picker") { pk.area = "opts"; pk.oi = i; o.toggle(); pickerRefresh(); } });
    ob.appendChild(d); vopts.push(d);
  });
  push("picker");
  pickerRefresh();
}
function pickerRefresh() {
  if (!pk) return;
  for (var i = 0; i < vcards.length; i++) {
    vcards[i].classList.toggle("focus", pk.area === "cards" && i === pk.idx);
    vcards[i].classList.toggle("cur", pk.items[i].key === pk.cur());
  }
  for (var j = 0; j < vopts.length; j++) {
    vopts[j].textContent = pk.opts[j].label();
    vopts[j].classList.toggle("focus", pk.area === "opts" && j === pk.oi);
  }
  $("vhint").textContent = pk.area === "cards"
    ? "◀ ▶ escolhe  ·  OK confirma  ·  Voltar cancela" + (vopts.length ? "  ·  ▼ opções" : "")
    : "▲ ▼ escolhe  ·  OK liga/desliga  ·  Voltar fecha";
}
function pickerSet(i) {
  if (i < 0 || i >= pk.items.length) return;
  pk.idx = i;
  pk.preview(pk.items[i].key);          // previa ao vivo
  pickerRefresh();
}
function pickerClose(commit) {
  var p = pk; pk = null;
  if (commit) p.commit(p.items[p.idx].key);
  else p.preview(p.cur());              // cancelou: volta ao que estava salvo
  if (p.after) p.after();
  pop(); refreshRows(); refreshFocus();
}
function pickerKey(k) {
  var n = pk.items.length, no = vopts.length;
  if (pk.area === "cards") {
    if (k === 37) pickerSet(pk.idx - 1);
    else if (k === 39) pickerSet(pk.idx + 1);
    else if (k === 40) { if (no) { pk.area = "opts"; pk.oi = 0; pickerRefresh(); } }
    else if (k === 13) pickerClose(true);
    else if (k === 461 || k === 27) pickerClose(false);
  } else {
    if (k === 38) { if (pk.oi > 0) pk.oi--; else pk.area = "cards"; pickerRefresh(); }
    else if (k === 40) { if (pk.oi < no - 1) { pk.oi++; pickerRefresh(); } }
    else if (k === 13 || k === 37 || k === 39) { pk.opts[pk.oi].toggle(); pickerRefresh(); }
    else if (k === 461 || k === 27) pickerClose(false);
  }
}

function toggleIntro() {
  introOn = !introOn;
  store("hz_intro", introOn ? "1" : "0");
  refreshRows();
}
function renderIntroOpt() { pickerRefresh(); }

function openVisual() {
  if (screen === "picker" || screen === "org") return;
  openPicker({
    title: "Visual", wide: false,
    items: STYLES.map(function (s) { return { key: s.key, name: s.name, sw: s.sw, desc: "" }; }),
    cur: function () { return savedStyle; },
    preview: function (k) { applyStyle(k); },
    commit: function (k) { savedStyle = k; store("hz_style", k); applyStyle(k); },
    opts: [{ label: function () { return "Animação de entrada: " + (introOn ? "ligada" : "desligada"); }, toggle: toggleIntro }]
  });
}
function openLife() {
  if (screen === "picker" || screen === "org") return;
  var z0 = zone, tid = (hdrItems()[hdrIndex] || {}).el ? hdrItems()[hdrIndex].el.id : null;
  openPicker({
    after: function () {                  // trocar de lifestyle muda a barra do topo: volta para o mesmo botao
      zone = z0;
      var L = hdrItems(); hdrIndex = 0;
      for (var i = 0; i < L.length; i++) if (L[i].el.id === tid) hdrIndex = i;
    },
    title: "Lifestyle", wide: true,
    items: LIFE_KEYS.map(function (k) { return { key: k, name: LIFE[k].name, sw: LIFE[k].sw, desc: LIFE[k].desc }; }),
    cur: function () { return savedLife; },
    preview: function (k) { if (k !== life) setLife(k); },
    commit: function (k) { savedLife = k; store("hz_life", k); if (k !== life) setLife(k); },
    opts: [{ label: function () { return "Mostrar notícias: " + (showNews ? "sim" : "não"); }, toggle: toggleNews }]
  });
}

// Configuracoes: Com som -> Sem som -> Desligada
function cycleIntro(d) {
  var m = !introOn ? 2 : (introSnd ? 0 : 1);
  m = (m + (d || 1) + 3) % 3;
  introOn = m !== 2;
  introSnd = m === 0;
  store("hz_intro", introOn ? "1" : "0");
  store("hz_introsnd", introSnd ? "1" : "0");
  renderIntroOpt(); refreshRows();
}
function introLabel() { return !introOn ? "Desligada" : (introSnd ? "Com som" : "Sem som"); }

function toggleClock() {
  clock24 = !clock24;
  store("hz_h24", clock24 ? "1" : "0");
  lastClock = ""; lastAp = null;                            // null forca atualizar o AM/PM (inclusive para apagar)
  tick(); refreshRows();
}

function playIntroNow() {                                   // "Ver animação agora"
  closeAll();
  startIntro();
}

// ============================================================
// ORGANIZAR APPS: escolher quais ficam na tela inicial e em que ordem
//   OK num app da tela -> Mover / Remover.   OK num app disponivel -> adiciona.
//   Limite: maxApps() (15). Fica salvo na TV (localStorage).
// ============================================================
var orgOpen = false;
var oSec = 0;            // 0 = na tela inicial, 1 = disponiveis, 2 = botao restaurar
var oIdx = 0;
var oMode = "nav";       // "nav", "pop" (menu Mover/Remover) ou "move"
var pIdx = 0;
var oDirty = false;
var oBackup = [];        // copia da lista ao abrir: "Voltar" volta para ela, "Confirmar" salva a nova

function saveLayout() { oDirty = true; }          // so marca; quem grava de verdade e o botao Confirmar
function persistLayout() {
  store(LIFE[life].key, JSON.stringify(APPS.map(function (a) { return a.name; })));
}

function loadLayout() {
  var names = [];
  try { names = JSON.parse(recall(LIFE[life].key, "null")) || []; } catch (e) { names = []; }
  APPS = [];
  names.forEach(function (n) {
    for (var i = 0; i < CATALOG.length; i++) {
      if (CATALOG[i].name === n && APPS.indexOf(CATALOG[i]) < 0 && APPS.length < maxApps()) { APPS.push(CATALOG[i]); break; }
    }
  });
  if (!APPS.length) resetLayout(true);
}

function resetLayout(silent) {
  APPS = [];
  LIFE[life].def.forEach(function (n) {
    for (var i = 0; i < CATALOG.length; i++) if (CATALOG[i].name === n) { APPS.push(CATALOG[i]); break; }
  });
  if (!silent) saveLayout();
}

function availApps() { return CATALOG.filter(function (a) { return APPS.indexOf(a) < 0; }); }

function popOpts() { return APPS.length > 1 ? ["Mover", "Remover", "Cancelar"] : ["Mover", "Cancelar"]; }

function chipFor(app, num) {
  var c = document.createElement("div");
  c.className = "chip2";
  c.style.setProperty("--a", app.a); c.style.setProperty("--b", app.b);
  var ic = document.createElement("div"); ic.className = "cico";
  if (iconCache[app.name]) { var im = document.createElement("img"); im.src = iconCache[app.name]; ic.appendChild(im); }
  else ic.innerHTML = app.icon ? ICON[app.icon] : '<span class="lt">' + app.letter + "</span>";
  var nm = document.createElement("div"); nm.className = "cname"; nm.textContent = app.name;
  c.appendChild(ic); c.appendChild(nm);
  if (num) { var n = document.createElement("div"); n.className = "cnum"; n.textContent = num; c.appendChild(n); }
  return c;
}

function renderOrg() {
  var home = $("ohome"), av = $("oavail"), list = availApps();
  home.innerHTML = ""; av.innerHTML = "";
  APPS.forEach(function (app, i) {
    var c = chipFor(app, i + 1);
    if (oSec === 0 && oIdx === i) c.classList.add(oMode === "move" ? "grab" : "focus");
    c.addEventListener("mouseenter", function () { if (orgOpen && oMode === "nav") { oSec = 0; oIdx = i; renderOrg(); } });
    c.addEventListener("click", function () { if (orgOpen && oMode === "nav") { oSec = 0; oIdx = i; orgOK(); } });
    home.appendChild(c);
  });
  list.forEach(function (app, i) {
    var c = chipFor(app, "");
    if (oSec === 1 && oIdx === i) c.classList.add("focus");
    c.addEventListener("mouseenter", function () { if (orgOpen && oMode === "nav") { oSec = 1; oIdx = i; renderOrg(); } });
    c.addEventListener("click", function () { if (orgOpen && oMode === "nav") { oSec = 1; oIdx = i; orgOK(); } });
    av.appendChild(c);
  });
  $("oavh").style.display = list.length ? "" : "none";
  var cnt = $("ocount");
  cnt.textContent = APPS.length + " de " + maxApps();
  cnt.className = "ocount" + (APPS.length >= maxApps() ? " full" : "");
  $("oreset").classList.toggle("focus", oSec === 2 && oIdx === 0);
  $("ocfm").classList.toggle("focus", oSec === 2 && oIdx === 1);

  var pop = $("opop");
  if (oMode === "pop") {
    pop.innerHTML = "";
    popOpts().forEach(function (t, i) {
      var d = document.createElement("div"); d.className = "popt" + (i === pIdx ? " focus" : ""); d.textContent = t;
      d.addEventListener("click", function () { pIdx = i; orgOK(); });
      pop.appendChild(d);
    });
    pop.classList.add("show");
  } else pop.classList.remove("show");

  $("ohint").textContent =
    oMode === "move" ? "◀ ▶ ▲ ▼ move o app  ·  OK solta" :
    oMode === "pop"  ? "▲ ▼ escolhe  ·  OK confirma  ·  Voltar cancela" :
    "◀ ▶ ▲ ▼ escolhe  ·  OK num app: mover ou remover  ·  OK num disponível: adiciona  ·  Confirmar salva  ·  Voltar cancela";
}

function openOrg() {
  if (screen === "picker" || screen === "org") return;
  orgOpen = true; oSec = 0; oIdx = 0; oMode = "nav"; oDirty = false;
  oBackup = APPS.slice();
  $("olife").textContent = "· " + LIFE[life].name;
  push("org");
  renderOrg();
}

// confirm = true salva a nova ordem; senao descarta o que foi mexido
function closeOrg(confirm) {
  orgOpen = false; oMode = "nav";
  if (confirm) {
    if (oDirty) { persistLayout(); rebuildGrid(); toast("Alterações salvas."); }
  } else if (oDirty) {
    APPS = oBackup.slice();
  }
  oDirty = false;
  pop(); refreshRows(); refreshFocus();       // volta para quem abriu (home ou Configuracoes)
}

function orgOK() {
  if (oMode === "pop") {
    var opt = popOpts()[pIdx];
    if (opt === "Mover") oMode = "move";
    else if (opt === "Remover") {
      APPS.splice(oIdx, 1);
      if (oIdx > APPS.length - 1) oIdx = APPS.length - 1;
      saveLayout(); oMode = "nav";
    } else oMode = "nav";
  } else if (oMode === "move") {
    oMode = "nav";
  } else if (oSec === 0) {
    oMode = "pop"; pIdx = 0;
  } else if (oSec === 1) {
    var list = availApps();
    if (APPS.length >= maxApps()) { toast("Limite de " + maxApps() + " apps. Remova um para adicionar outro."); return; }
    if (list[oIdx]) {
      APPS.push(list[oIdx]); saveLayout();
      var left = availApps().length;
      if (!left) { oSec = 0; oIdx = APPS.length - 1; }
      else if (oIdx > left - 1) oIdx = left - 1;
    }
  } else if (oIdx === 1) {
    closeOrg(true); return;
  } else {
    resetLayout(false); oSec = 0; oIdx = 0;
    toast("Padrão restaurado. Aperte Confirmar para salvar.");
  }
  renderOrg();
}

// Magic Remote nos botoes de baixo (Restaurar padrao / Confirmar)
[["oreset", 0], ["ocfm", 1]].forEach(function (b) {
  var el = $(b[0]);
  el.addEventListener("mouseenter", function () { if (orgOpen && oMode === "nav") { oSec = 2; oIdx = b[1]; renderOrg(); } });
  el.addEventListener("click", function () { if (orgOpen && oMode === "nav") { oSec = 2; oIdx = b[1]; orgOK(); } });
});

function orgKey(k) {
  if (oMode === "pop") {
    var n = popOpts().length;
    if (k === 38) { if (pIdx > 0) pIdx--; }
    else if (k === 40) { if (pIdx < n - 1) pIdx++; }
    else if (k === 13) { orgOK(); return; }
    else if (k === 461 || k === 27) oMode = "nav";
    renderOrg(); return;
  }
  if (oMode === "move") {
    var t = oIdx;
    if (k === 37) t = oIdx - 1; else if (k === 39) t = oIdx + 1;
    else if (k === 38) t = oIdx - COLS; else if (k === 40) t = oIdx + COLS;
    if ((k === 37 || k === 38 || k === 39 || k === 40)) {
      if (t >= 0 && t < APPS.length && t !== oIdx) {
        var tmp = APPS[oIdx]; APPS[oIdx] = APPS[t]; APPS[t] = tmp;
        oIdx = t; saveLayout();
      }
    } else if (k === 13 || k === 461 || k === 27) oMode = "nav";
    renderOrg(); return;
  }

  var avn = availApps().length;
  var len = oSec === 0 ? APPS.length : (oSec === 1 ? avn : 2);
  if (k === 37) { if (oIdx > 0) oIdx--; }
  else if (k === 39) { if (oIdx < len - 1) oIdx++; }
  else if (k === 38) {
    if (oSec === 2) { if (avn) { oSec = 1; oIdx = Math.floor((avn - 1) / COLS) * COLS; } else { oSec = 0; oIdx = Math.floor((APPS.length - 1) / COLS) * COLS; } }
    else if (oIdx >= COLS) oIdx -= COLS;
    else if (oSec === 1) { var col = oIdx % COLS; oSec = 0; oIdx = Math.min(APPS.length - 1, Math.floor((APPS.length - 1) / COLS) * COLS + col); }
  }
  else if (k === 40) {
    if (oSec < 2 && oIdx + COLS < len) oIdx += COLS;
    else if (oSec < 2 && Math.floor(oIdx / COLS) < Math.floor((len - 1) / COLS)) oIdx = len - 1;
    else if (oSec === 0 && avn) { oSec = 1; oIdx = Math.min(avn - 1, oIdx % COLS); }
    else if (oSec < 2) { oSec = 2; oIdx = 1; }
  }
  else if (k === 13) { orgOK(); return; }
  else if (k === 461 || k === 27) { closeOrg(false); return; }
  renderOrg();
}

// ============================================================
// CONTROLE REMOTO - um unico tratador; cada tela cuida das suas teclas.
//   Voltar (461/Esc) sempre sobe um nivel.
//   Atalhos: vermelho = Configuracoes, verde = Lifestyle, amarelo = Visual, azul = diagnostico
// ============================================================
var KEYS = {
  reader: function (k) { readerKey(k); },
  prompt: function (k) { promptKey(k); },
  home: function (k) { homeKey(k); },
  settings: function (k) { settingsKey(k); },
  picker: function (k) { pickerKey(k); },
  org: function (k) { orgKey(k); }
};

function shortcut(k) {
  if (screen !== "home" && screen !== "settings") return false;
  if (k === 403) { if (screen === "home") openSettings(); return true; }
  if (k === 404) { openLife(); return true; }
  if (k === 405) { openVisual(); return true; }
  return false;
}

document.addEventListener("keydown", function (e) {
  var k = e.keyCode;

  if (k === 406) { toggleDebug(); return; }            // botao azul: diagnostico dos icones

  if (!introDone) {                       // qualquer tecla pula a entrada (depois de 1,2 s)
    if (Date.now() - introStart < 1200) return;
    if (k === 461 || k === 27) { leaveApp(); return; }
    endIntro();
    return;
  }

  if (shortcut(k)) return;
  if (KEYS[screen]) KEYS[screen](k);
});

// ============================================================
// RELOGIO E SAUDACAO (sem depender do idioma da TV)
// ============================================================
var WD = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
var MO = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
var lastClock = "", lastAp = "", lastDate = "", lastHello = "";
var clock24 = true;           // true = 24 horas, false = 12 horas (AM/PM)

function tick() {
  var d = new Date();
  var h = d.getHours();
  var mi = ("0" + d.getMinutes()).slice(-2);
  var clock, ap = "";
  if (clock24) clock = ("0" + h).slice(-2) + ":" + mi;
  else { ap = h < 12 ? "AM" : "PM"; clock = (h % 12 || 12) + ":" + mi; }
  var date = WD[d.getDay()] + ", " + d.getDate() + " de " + MO[d.getMonth()];
  var hello = h < 12 ? "Bom dia" : (h < 18 ? "Boa tarde" : "Boa noite");

  if (clock !== lastClock) { $("clock").textContent = clock; lastClock = clock; }
  if (ap !== lastAp) { $("ampm").textContent = ap; lastAp = ap; }
  if (date !== lastDate)   { $("date").textContent = date;   lastDate = date; }
  if (hello !== lastHello) { $("hello").textContent = hello; lastHello = hello; }
}

// ============================================================
// ENTRADA: fundo branco, o H forma "Horizon", pico de luz, aparece "TV"
// So usa transform e opacity (leve para a TV). As animacoes so comecam
// depois que a tela ja foi pintada, e a entrada termina quando a ultima
// animacao acaba - nao num tempo fixo que pode cortar tudo no meio.
// ============================================================
function buildIntroLetters() {
  var box = $("letters");
  var word = "Horizon";
  var c1 = [0x2f, 0x78, 0xee], c2 = [0x12, 0xa5, 0x94];
  for (var k = 0; k < word.length; k++) {
    var t = k / (word.length - 1);
    var rgb = [0, 1, 2].map(function (j) { return Math.round(c1[j] + (c2[j] - c1[j]) * t); });
    var s = document.createElement("span");
    s.className = k === 0 ? "l h" : "l r";
    s.textContent = word.charAt(k);
    s.style.color = "rgb(" + rgb.join(",") + ")";           // cor solida por letra (sem recorte de degrade, que falhava com animacao)
    if (k > 0) s.style.animationDelay = (1.3 + (k - 1) * 0.18).toFixed(2) + "s";   // uma letra a cada 0,18 s
    box.appendChild(s);
  }

  var tv = document.querySelector(".i-tv");
  var onEnd = function () {
    if (introDone) return;
    clearTimeout(introTimer);
    introTimer = setTimeout(endIntro, 1700);                // segura o logo completo ate o som acabar
  };
  tv.addEventListener("animationend", onEnd);
  tv.addEventListener("webkitAnimationEnd", onEnd);
}

// ---- som da entrada (intro.mp3, sintetizado, ~6,5 s; o climax cai em 3,2 s, junto do pico de luz) ----
var introAudio = null;
var introSnd = true;
function prepAudio() {
  try { introAudio = new Audio("intro.mp3"); introAudio.preload = "auto"; introAudio.volume = 0.9; }
  catch (e) { introAudio = null; }
}
function playIntroSound() {
  if (!introAudio || !introSnd) return;
  try {
    introAudio.currentTime = 0;
    var p = introAudio.play();
    if (p && p.catch) p.catch(function () {});
  } catch (e) {}
}
function stopIntroSound() {
  if (!introAudio) return;
  try { introAudio.pause(); introAudio.currentTime = 0; } catch (e) {}
}

function startIntro() {
  var intro = $("intro");
  stopIntroSound();
  clearTimeout(introTimer);
  introDone = false;
  introStart = Date.now();
  document.body.classList.remove("ready");
  intro.style.display = "flex";
  intro.classList.remove("out");
  intro.classList.remove("play");
  void intro.offsetWidth;                                   // forca recomecar do zero
  var go = function () {
    introStart = Date.now();
    intro.classList.add("play");
    playIntroSound();
    introTimer = setTimeout(endIntro, 9500);                // seguranca, se algo travar
  };
  // espera a primeira pintura da tela branca antes de animar
  if (window.requestAnimationFrame) requestAnimationFrame(function () { requestAnimationFrame(go); });
  else setTimeout(go, 60);
}

function endIntro() {
  if (introDone) return;
  introDone = true;
  clearTimeout(introTimer);
  stopIntroSound();                                         // se pulou a entrada, corta o som
  var intro = $("intro");
  intro.classList.add("out");
  document.body.classList.add("ready");
  setTimeout(function () { if (introDone) intro.style.display = "none"; }, 750);
}

// Voltar para o launcher (o app ficou em segundo plano): toca a entrada de novo
var lastReplay = 0;
var wasHidden = false;
function replay() {
  var now = Date.now();
  if (now - lastReplay < 1000) return;
  lastReplay = now;
  closeAll();
  zone = "content"; index = 0; cyRow = 0; cyTab = "home"; hdrIndex = 0;
  $("cyber").setAttribute("data-tab", "home");
  refreshFocus();
  if (introOn) startIntro();
}

function onVis() {
  var hidden = document.hidden || document.webkitHidden;
  if (hidden) wasHidden = true;
  else if (wasHidden) { wasHidden = false; replay(); }
}
document.addEventListener("visibilitychange", onVis);
document.addEventListener("webkitvisibilitychange", onVis);
document.addEventListener("webOSRelaunch", replay);
window.addEventListener("pageshow", function (e) { if (e.persisted) replay(); });

// Detector que nao depende de eventos: se o app ficou congelado em segundo plano
// (a TV para os timers), o relogio de 1 s "pula". Ao voltar, toca a entrada.
var lastBeat = Date.now();
setInterval(function () {
  var now = Date.now();
  if (introDone && now - lastBeat > 3000 && !(document.hidden || document.webkitHidden)) replay();
  lastBeat = now;
}, 1000);

// ============================================================
// ICONES REAIS
// Ordem: 1) imagem sua em logos/<nome>.png   2) icone do app instalado na TV
//        3) o que foi achado da ultima vez     4) icone desenhado (degrade)
// A TV e consultada por listLaunchPoints (o mesmo que a tela inicial da LG usa)
// e por listApps; o app e achado pelo ID, depois pelo nome, depois por pedaco do ID.
// ============================================================
var LOGO = {
  "Netflix": "netflix", "YouTube": "youtube", "Prime Video": "primevideo",
  "Globoplay": "globoplay", "YouTube Music": "youtubemusic",
  "Disney+": "disneyplus", "Spotify": "spotify",
  "Max": "max", "Apple TV": "appletv", "Paramount+": "paramountplus",
  "Crunchyroll": "crunchyroll", "Twitch": "twitch", "Pluto TV": "plutotv",
  "Deezer": "deezer", "Plex": "plex"
};

var applied = {};      // indice -> src ja aplicado
var dbg = { lp: "pendente", la: "pendente", apps: [] };

function fileUrl(p, base) {
  if (!p) return null;
  if (/^(file|https?|data):/i.test(p)) return p;
  if (p.charAt(0) !== "/" && base) p = base.replace(/\/$/, "") + "/" + p;
  return p.charAt(0) === "/" ? "file://" + p : p;
}

function tryImages(list, done) {
  var n = 0;
  (function next() {
    if (n >= list.length) { done(null); return; }
    var img = new Image();
    var src = list[n++];
    img.onload = function () { done(src); };
    img.onerror = next;
    img.src = src;
  })();
}

function applyImage(i, src) {
  if (applied[i] === src) return;
  applied[i] = src;
  var ico = cells[i]._ico;
  ico.classList.add("has-img");
  ico.innerHTML = "";
  var img = document.createElement("img");
  img.src = src;
  ico.appendChild(img);
}

// procura o app da lista dentro do que a TV devolveu
function findTv(app, byId, byTitle, all) {
  if (app.id && byId[app.id]) return byId[app.id];
  var t = app.titles || [];
  for (var i = 0; i < t.length; i++) if (byTitle[t[i]]) return byTitle[t[i]];
  var h = app.hints || [];
  for (var j = 0; j < h.length; j++) {
    for (var k = 0; k < all.length; k++) {
      var id = (all[k].id || "").toLowerCase();
      if (id.indexOf(h[j]) !== -1 && id.indexOf("alexa") === -1 && id.indexOf("kids") === -1) return all[k];
    }
  }
  return null;
}

var tvAll = [], tvById = {}, tvByTitle = {}, tvReady = false, iconCache = {};

// ------------------------------------------------------------
// ICONES OFICIAIS AUTOMATICOS
// A LG nao deixa apps instalados por voce lerem os icones da propria TV
// (listApps/listLaunchPoints sao bloqueados). Entao o launcher busca o
// icone oficial do app na App Store (Apple iTunes API, gratuita) so na
// primeira vez e guarda o endereco. Precisa da TV na internet.
// [bundle id do app no iOS, nome para buscar se o id falhar]
// ------------------------------------------------------------
var OFFICIAL = {
  "Netflix":       ["com.netflix.Netflix", "netflix"],
  "YouTube":       ["com.google.ios.youtube", "youtube"],
  "Prime Video":   ["com.amazon.aiv.AIVApp", "prime video"],
  "Globoplay":     ["com.globo.globoplay", "globoplay"],
  "YouTube Music": ["com.google.ios.youtubemusic", "youtube music"],
  "Disney+":       ["com.disney.disneyplus", "disney+"],
  "Spotify":       ["com.spotify.client", "spotify"],
  "Max":           ["com.hbo.hbonow", "max"],
  "Apple TV":      ["com.apple.TVWatchList", "apple tv"],
  "Paramount+":    ["com.cbsvideo.app", "paramount+"],
  "Crunchyroll":   ["com.crunchyroll.iphone", "crunchyroll"],
  "Twitch":        ["tv.twitch", "twitch"],
  "Pluto TV":      ["tv.pluto.ios", "pluto tv"],
  "Deezer":        ["com.deezer.Deezer", "deezer"],
  "Plex":          ["com.plexapp.plex", "plex"]
};
var itN = 0, itQ = [], itBusy = false;

function itJsonp(url, cb) {
  var name = "__it" + (++itN), sc = document.createElement("script"), done = false;
  function fin(r) {
    if (done) return;
    done = true;
    try { delete window[name]; } catch (e) { window[name] = undefined; }
    if (sc.parentNode) sc.parentNode.removeChild(sc);
    cb(r);
  }
  window[name] = function (r) { fin(r); };
  sc.onerror = function () { fin(null); };
  setTimeout(function () { fin(null); }, 7000);
  sc.src = url + (url.indexOf("?") < 0 ? "?" : "&") + "callback=" + name;
  document.head.appendChild(sc);
}

function artFrom(r, term) {
  var res = (r && r.results) || [];
  for (var i = 0; i < res.length; i++) {
    var n = (res[i].trackName || "").toLowerCase();
    if (res[i].artworkUrl512 && (!term || n.indexOf(term) !== -1)) return res[i].artworkUrl512;
  }
  return null;
}

function fetchOfficial(app, cb) {
  var o = OFFICIAL[app.name];
  if (!o) { cb(null); return; }
  itQ.push({ app: app, o: o, cb: cb });
  if (!itBusy) runItQ();
}
function runItQ() {
  var j = itQ.shift();
  if (!j) { itBusy = false; return; }
  itBusy = true;
  var next = function (u) { j.cb(u); setTimeout(runItQ, 450); };     // um pedido por vez (a API limita ~20/min)
  itJsonp("https://itunes.apple.com/lookup?bundleId=" + encodeURIComponent(j.o[0]) + "&country=br", function (r) {
    var u = artFrom(r, null);
    if (u) { next(u); return; }
    itJsonp("https://itunes.apple.com/search?term=" + encodeURIComponent(j.o[1]) + "&entity=software&country=br&limit=5", function (r2) {
      next(artFrom(r2, j.o[1]));
    });
  });
}



function logosFor(app) {
  var slug = LOGO[app.name], list = [];
  if (slug) list.push("logos/" + slug + ".png", "logos/" + slug + ".jpg", "logos/" + slug + ".svg");
  return list;
}

function tvAdd(a) {
  if (!a || !a.id) return;
  var cur = tvById[a.id];
  if (cur) {                                   // junta o que um e outro trouxeram
    for (var k in a) if (a[k] && !cur[k]) cur[k] = a[k];
    return;
  }
  tvById[a.id] = a;
  tvAll.push(a);
  var ti = (a.title || "").toLowerCase();
  if (ti && !tvByTitle[ti]) tvByTitle[ti] = a;
}

// procura a imagem de todos os apps do catalogo (os da tela e os que da pra adicionar)
function resolveIcons() {
  dbg.apps = [];
  CATALOG.forEach(function (app) {
    var rec = { name: app.name, found: "-", tried: 0, shown: "-" };
    dbg.apps.push(rec);
    if (!LOGO[app.name]) return;                // Navegador/Entradas/etc. ficam com o desenho

    var tv = tvReady ? findTv(app, tvById, tvByTitle, tvAll) : null;
    var list = logosFor(app);
    if (tv) {
      rec.found = tv.id + " (" + (tv.title || "?") + ")";
      if (tv.id !== app.id && app.id) app.rid = tv.id;            // ID certo, caso o do app.js esteja errado
      else if (!app.id) app.rid = tv.id;
      var base = tv.folderPath || "";
      if (tv.largeIcon) list.push(fileUrl(tv.largeIcon, base));
      if (tv.icon) list.push(fileUrl(tv.icon, base));
    } else {
      rec.found = tvReady ? "nao achei na TV" : "TV ainda nao respondeu";
    }
    if (iconCache[app.name]) list.push(iconCache[app.name]);
    rec.tried = list.length;

    function ok(src) {
      rec.shown = src;
      iconCache[app.name] = src;
      store("hz_icons", JSON.stringify(iconCache));
      var j = APPS.indexOf(app);
      if (j >= 0 && cells[j]) applyImage(j, src);
      if (orgOpen) renderOrg();
      if (dbgEl && dbgEl.style.display === "block") renderDebug();
    }
    tryImages(list, function (src) {
      if (src) { ok(src); return; }
      // nada local/da TV: busca o icone oficial na App Store (so uma vez por app)
      var lastFail = parseInt(recall("hz_nf_" + app.name, "0"), 10) || 0;      // se falhou nas ultimas 24 h, nao insiste
      if (!tvReady || app._off || !OFFICIAL[app.name] || Date.now() - lastFail < 86400000) {
        rec.shown = "desenhado (nenhuma imagem carregou)";
        if (dbgEl && dbgEl.style.display === "block") renderDebug();
        return;
      }
      app._off = true;
      rec.shown = "buscando icone oficial...";
      fetchOfficial(app, function (u) {
        if (!u) { store("hz_nf_" + app.name, String(Date.now())); rec.shown = "desenhado (sem internet ou nao achei)"; if (dbgEl && dbgEl.style.display === "block") renderDebug(); return; }
        tryImages([u], function (ok2) {
          if (ok2) ok(ok2);
          else { rec.shown = "desenhado (icone oficial nao carregou)"; if (dbgEl && dbgEl.style.display === "block") renderDebug(); }
        });
      });
    });
  });
}

function loadIcons() {
  var waiting = 2, finished = false;

  function settle() {
    if (finished) return;
    finished = true;
    tvReady = true;
    resolveIcons();
  }
  function oneDone() { waiting--; if (waiting <= 0) settle(); }

  // 0) mostra de imediato as imagens da pasta logos/ e o que ja tinha sido achado (sem esperar a TV)
  resolveIcons();

  luna("luna://com.webos.applicationManager/listLaunchPoints", {},
    function (res) { dbg.lp = "erro: " + (res.errorText || res.errorCode || "?"); oneDone(); },
    function (res) {
      var lp = res.launchPoints || [];
      dbg.lp = "ok, " + lp.length + " itens";
      lp.forEach(function (p) {
        tvAdd({ id: p.id, title: p.title, icon: p.icon, largeIcon: p.largeIcon, folderPath: "" });
      });
      oneDone();
    });

  luna("luna://com.webos.applicationManager/listApps", {},
    function (res) { dbg.la = "erro: " + (res.errorText || res.errorCode || "?"); oneDone(); },
    function (res) {
      var ap = res.apps || [];
      dbg.la = "ok, " + ap.length + " itens";
      ap.forEach(function (a) {
        tvAdd({ id: a.id, title: a.title, icon: a.icon, largeIcon: a.largeIcon, folderPath: a.folderPath || "" });
      });
      oneDone();
    });

  setTimeout(settle, 2500);                       // se a TV nao responder
}

// ---------- diagnostico (botao azul do controle) ----------
var dbgEl = null;
function renderDebug() {
  var t = "DIAGNOSTICO DE ICONES  (botao azul fecha)\n" +
          "listLaunchPoints: " + dbg.lp + "\nlistApps: " + dbg.la + "\n\n";
  dbg.apps.forEach(function (r) {
    t += r.name + "\n   TV: " + r.found + "\n   icone: " + r.shown + "\n";
  });
  dbgEl.textContent = t;
}
function toggleDebug() {
  if (!dbgEl) { dbgEl = document.createElement("div"); dbgEl.id = "dbg"; document.body.appendChild(dbgEl); }
  var show = dbgEl.style.display !== "block";
  dbgEl.style.display = show ? "block" : "none";
  if (show) renderDebug();
}

// ============================================================
// CONFIGURACOES (aba) - lista agrupada, estilo iPhone
// Fala com a TV pelos servicos do webOS. Se a TV bloquear algum, a linha
// avisa e "Todas as configuracoes" abre o app de ajustes da propria TV.
// ============================================================
var VERSION = "2.1.0";

var PIC = [["vivid", "Vívido"], ["standard", "Padrão"], ["cinema", "Cinema"], ["sports", "Esporte"], ["game", "Jogo"]];
var SND = [["standard", "Padrão"], ["cinema", "Cinema"], ["clearVoice", "Voz clara"], ["sports", "Esporte"], ["music", "Música"], ["game", "Jogo"]];
var OUT = [["tv_speaker", "Alto-falante da TV"], ["external_arc", "HDMI ARC"], ["external_optical", "Óptico"], ["bt_soundbar", "Bluetooth"]];

function lab(list, v) {
  if (v === null || v === undefined) return "—";
  for (var i = 0; i < list.length; i++) if (list[i][0] === v) return list[i][1];
  return String(v);
}
function nextKey(list, cur, dir) {
  var p = -1;
  for (var i = 0; i < list.length; i++) if (list[i][0] === cur) p = i;
  if (p < 0) p = dir > 0 ? -1 : 0;
  return list[(p + dir + list.length) % list.length][0];
}

var S = { wifi: null, wired: null, pic: null, snd: null, out: null, vol: null, ok: 0, fail: 0 };
var ROWS = [];
var rIndex = 0;

var SVA = 'viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
var SIC = {
  wifi:  '<svg ' + SVA + '><path d="M2.5 9.5a14 14 0 0 1 19 0M5.5 13a9.5 9.5 0 0 1 13 0M8.8 16.4a5 5 0 0 1 6.4 0"/><circle cx="12" cy="19.6" r="1.2" fill="#fff"/></svg>',
  bt:    '<svg ' + SVA + '><path d="M7 7.5l10 9-5 4.5V3l5 4.5-10 9"/></svg>',
  net:   '<svg ' + SVA + '><rect x="8" y="3" width="8" height="6" rx="1.5"/><path d="M12 9v4M5 13h14M5 13v3M19 13v3M12 13v3"/><rect x="3" y="16" width="4" height="4" rx="1"/><rect x="10" y="16" width="4" height="4" rx="1"/><rect x="17" y="16" width="4" height="4" rx="1"/></svg>',
  tv:    '<svg ' + SVA + '><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>',
  eq:    '<svg ' + SVA + ' stroke-width="2.6"><path d="M6 5v14M12 9v10M18 3v18"/></svg>',
  vol:   '<svg ' + SVA + '><path d="M4 9.5v5h4l5 4v-13l-5 4z" fill="#fff"/><path d="M16.5 9a4.5 4.5 0 0 1 0 6M19 6.5a8 8 0 0 1 0 11"/></svg>',
  bar:   '<svg ' + SVA + '><rect x="2.5" y="9" width="19" height="6" rx="2"/><circle cx="7" cy="12" r="1" fill="#fff"/><circle cx="17" cy="12" r="1" fill="#fff"/></svg>',
  bolt:  '<svg ' + SVA + '><path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z" fill="#fff"/></svg>',
  game:  '<svg ' + SVA + '><rect x="2.5" y="7" width="19" height="11" rx="5.5"/><path d="M7.5 10.5v4M5.5 12.5h4"/><circle cx="15.5" cy="11.5" r="1" fill="#fff"/><circle cx="18" cy="13.5" r="1" fill="#fff"/></svg>',
  power: '<svg ' + SVA + '><path d="M12 3v8"/><path d="M6.3 6.5a8 8 0 1 0 11.4 0"/></svg>',
  moon:  '<svg ' + SVA + '><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" fill="#fff"/></svg>',
  paint: '<svg ' + SVA + '><path d="M12 3a9 9 0 0 0 0 18c1.1 0 1.8-.9 1.8-1.8 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-1 .8-1.8 1.8-1.8H17a4 4 0 0 0 4-4c0-4.4-4-8-9-8z"/><circle cx="7.5" cy="11.5" r="1" fill="#fff"/><circle cx="10.5" cy="7.5" r="1" fill="#fff"/><circle cx="15" cy="7.5" r="1" fill="#fff"/></svg>',
  spark: '<svg ' + SVA + '><path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" fill="#fff"/></svg>',
  gear:  '<svg ' + SVA + '><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1"/></svg>',
  info:  '<svg ' + SVA + '><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5v.2"/></svg>',
  clock: '<svg ' + SVA + '><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>',
  play:  '<svg ' + SVA + '><path d="M8.5 5.5v13l10-6.5z" fill="#fff"/></svg>',
  grid:  '<svg ' + SVA + '><rect x="4" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.8"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.8"/><path d="M16.7 13.5v6.5M13.5 16.7H20"/></svg>'
};

// ---------- conversa com a TV ----------
function getSetting(cat, key, cb) {
  luna("luna://com.webos.service.settings/getSystemSettings", { category: cat, keys: [key] },
    function () { S.fail++; cb(null); },
    function (res) {
      var v = res.settings ? res.settings[key] : null;
      if (v === undefined) v = null;
      S.ok++; cb(v);
    });
}

function refreshSettings() {
  S.ok = 0; S.fail = 0;
  luna("luna://com.webos.service.connectionmanager/getStatus", {},
    function () { S.fail++; S.wifi = null; S.wired = null; refreshRows(); },
    function (res) {
      S.ok++;
      var w = res.wifi || {}, c = res.wired || {};
      S.wifi = w.state === "connected" ? (w.ssid || "Conectado") : "Desconectado";
      S.wired = c.state === "connected" ? "Conectado" : "Sem cabo";
      refreshRows();
    });
  getSetting("picture", "pictureMode", function (v) { S.pic = v; refreshRows(); });
  getSetting("sound", "soundMode",     function (v) { S.snd = v; refreshRows(); });
  getSetting("sound", "soundOutput",   function (v) { S.out = v; refreshRows(); });
  luna("luna://com.webos.audio/getVolume", {},
    function () { S.fail++; },
    function (res) {
      var v = res.volume;
      if (v === undefined && res.volumeStatus) v = res.volumeStatus.volume;
      if (typeof v === "number") { S.ok++; S.vol = v; refreshRows(); }
    });
  setTimeout(function () { sNoRead = (S.ok === 0 && S.fail > 0); setHint(); }, 1800);
}

function failToast() { toast("A TV não deixou mudar isso por aqui. Use “Todas as configurações”."); }

function applySet(cat, key, val, field) {
  var old = S[field];
  S[field] = val; refreshRows();
  var st = {}; st[key] = val;
  luna("luna://com.webos.service.settings/setSystemSettings", { category: cat, settings: st },
    function () { S[field] = old; refreshRows(); failToast(); });
}

function openSys() {
  luna("luna://com.webos.applicationManager/launch", { id: "com.palm.app.settings" },
    function () { toast("Não consegui abrir as configurações da TV."); });
}

function adjVol(d) {
  var v = S.vol === null ? 20 : S.vol;
  v = Math.max(0, Math.min(100, v + d * 5));
  S.vol = v; refreshRows();
  luna("luna://com.webos.audio/setVolume", { volume: v }, function () { toast("Não consegui mudar o volume por aqui."); });
}

function toggleGame() {
  if (S.pic === "game") {
    var prev = recall("hz_prevpic", "standard");
    applySet("picture", "pictureMode", prev === "game" ? "standard" : prev, "pic");
  } else {
    store("hz_prevpic", S.pic || "standard");
    applySet("picture", "pictureMode", "game", "pic");
  }
}

function applyPerf() { document.documentElement.classList.toggle("lite", perf === "lite"); }
function togglePerf() {
  perf = perf === "lite" ? "normal" : "lite";
  store("hz_perf", perf);
  applyPerf(); refreshRows();
}

function screenOff() {
  luna("luna://com.webos.service.tvpower/power/turnOffScreen", {},
    function () { toast("A TV não deixou desligar a tela por aqui."); });
}

// ---------- linhas ----------
// Duas colunas: ESQUERDA = categorias, DIREITA = linhas da categoria escolhida.
//   Categorias:  ▲ ▼ escolhe · ▶ ou OK entra · Voltar fecha
//   Linhas:      ▲ ▼ escolhe · ◀ ▶ muda o valor · OK abre · Voltar volta para as categorias
//   (▲ na primeira linha NAO fecha mais nada; nao existe mais "segurar" tecla)
SIC.layers = '<svg ' + SVA + '><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5M3 16.5l9 5 9-5"/></svg>';
SIC.sync   = '<svg ' + SVA + '><path d="M20 11a8 8 0 0 0-14-4.5L4 9"/><path d="M4 4v5h5"/><path d="M4 13a8 8 0 0 0 14 4.5L20 15"/><path d="M20 20v-5h-5"/></svg>';
SIC.news   = '<svg ' + SVA + '><rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><path d="M7 9h10M7 12.5h10M7 16h6"/></svg>';

var CATS = [
  { key: "home", name: "Tela inicial",  ic: "layers", color: "#ff375f" },
  { key: "net",  name: "Conexões",      ic: "wifi",   color: "#0a84ff" },
  { key: "av",   name: "Imagem e som",  ic: "tv",     color: "#af52de" },
  { key: "perf", name: "Desempenho",    ic: "bolt",   color: "#ffb000" },
  { key: "upd",  name: "Atualização",   ic: "sync",   color: "#30b0c7" },
  { key: "gen",  name: "Geral",         ic: "gear",   color: "#8e8e93" }
];
var cIndex = 0, rIndex = 0, sFocus = "cats", sNoRead = false;
var BYCAT = {};

function defineRows() {
  var ST = function () { for (var i = 0; i < STYLES.length; i++) if (STYLES[i].key === savedStyle) return STYLES[i].name; return ""; };
  ROWS = [
    { cat: "home", ic: "layers", color: "#ff375f", label: "Lifestyle", val: function () { return LIFE[savedLife].name; }, go: function () { openLife(); } },
    { cat: "home", ic: "paint",  color: "#ff9500", label: "Visual", val: ST, go: function () { openVisual(); } },
    { cat: "home", ic: "grid",   color: "#32ade6", label: "Organizar apps", val: function () { return APPS.length + " de " + maxApps(); }, go: function () { openOrg(); } },
    { cat: "home", ic: "news",   color: "#34c759", label: "Mostrar notícias", on: function () { return showNews; }, go: toggleNews, adj: toggleNews },

    { cat: "net", ic: "wifi", color: "#0a84ff", label: "Wi-Fi",       val: function () { return S.wifi || "—"; }, go: openSys },
    { cat: "net", ic: "bt",   color: "#1d6fe0", label: "Bluetooth",   go: openSys },
    { cat: "net", ic: "net",  color: "#34c759", label: "Rede (cabo)", val: function () { return S.wired || "—"; }, go: openSys },

    { cat: "av", ic: "tv",  color: "#af52de", label: "Modo de imagem", val: function () { return lab(PIC, S.pic); },
      adj: function (d) { applySet("picture", "pictureMode", nextKey(PIC, S.pic, d), "pic"); } },
    { cat: "av", ic: "eq",  color: "#ff2d55", label: "Modo de som",    val: function () { return lab(SND, S.snd); },
      adj: function (d) { applySet("sound", "soundMode", nextKey(SND, S.snd, d), "snd"); } },
    { cat: "av", ic: "vol", color: "#ff9500", label: "Volume",         val: function () { return S.vol === null ? "—" : String(S.vol); },
      pct: function () { return S.vol || 0; }, adj: adjVol },
    { cat: "av", ic: "bar", color: "#5856d6", label: "Saída de som",   val: function () { return lab(OUT, S.out); },
      adj: function (d) { applySet("sound", "soundOutput", nextKey(OUT, S.out, d), "out"); } },

    { cat: "perf", ic: "bolt",  color: "#ffb000", label: "Modo desempenho", val: function () { return perf === "lite" ? "Leve" : "Normal"; },
      adj: togglePerf, go: togglePerf },
    { cat: "perf", ic: "game",  color: "#30b0c7", label: "Modo jogo", on: function () { return S.pic === "game"; }, go: toggleGame, adj: toggleGame },
    { cat: "perf", ic: "power", color: "#636366", label: "Desligar a tela", go: screenOff },

    { cat: "gen", ic: "clock", color: "#0a84ff", label: "Formato da hora", val: function () { return clock24 ? "24 horas" : "12 horas"; },
      go: toggleClock, adj: toggleClock },
    { cat: "gen", ic: "moon",  color: "#3a3a5c", label: "Tema", val: function () { return theme === "dark" ? "Escuro" : "Padrão"; },
      go: toggleTheme, adj: toggleTheme },
    { cat: "gen", ic: "spark", color: "#5e5ce6", label: "Animação de entrada", val: introLabel,
      go: function () { cycleIntro(1); }, adj: function (d) { cycleIntro(d); } },
    { cat: "gen", ic: "play",  color: "#34c759", label: "Ver a animação agora", go: playIntroNow },
    { cat: "gen", ic: "gear",  color: "#8e8e93", label: "Todas as configurações", go: openSys },
    { cat: "upd", ic: "sync",  color: "#30b0c7", label: "Verificar atualização", val: function () { return updText(); }, go: function () { runCheck(true); } },
    { cat: "upd", ic: "play",  color: "#34c759", label: "Aplicar versão baixada", val: function () { return window.HZOTA && HZOTA.ready ? "reiniciar para " + HZOTA.ready : "nenhuma pendente"; },
      go: function () { if (window.HZOTA && HZOTA.ready) HZOTA.apply(); else toast("Nenhuma atualização baixada. Use Verificar atualização."); } },
    { cat: "upd", ic: "bolt",  color: "#ff9500", label: "Atualizar sozinho ao abrir", on: function () { return autoUpd; }, go: toggleAutoUpd, adj: toggleAutoUpd },
    { cat: "upd", ic: "net",   color: "#0a84ff", label: "Endereço do site", val: function () { return siteLabel(); }, go: function () { askSite(); } },
    { cat: "upd", ic: "news",  color: "#ff375f", label: "Atualizar notícias agora", val: function () { return newsStatus() || "—"; }, go: function () { loadNews(true); } },
    { cat: "upd", ic: "info",  color: "#8e8e93", label: "Versão em uso", val: function () { return VERSION + (window.HZOTA && HZOTA.source === "site" ? " (do site)" : " (do app)"); },
      go: function () { toast("Horizon TV " + VERSION + (window.HZOTA ? " · app instalado: " + HZOTA.bundled : "")); } },
    { cat: "gen", ic: "info",  color: "#8e8e93", label: "Sobre", val: function () { return "Horizon TV " + VERSION; },
      go: function () { toast("Horizon TV " + VERSION + "  ·  botão azul = diagnóstico de ícones"); } }
  ];
  BYCAT = {};
  CATS.forEach(function (c) { BYCAT[c.key] = []; });
  ROWS.forEach(function (r) { BYCAT[r.cat].push(r); });
}
function curRows() { return BYCAT[CATS[cIndex].key]; }

function updateRow(r) {
  if (r.vEl && r.val) r.vEl.textContent = r.val();
  if (r.on && r.xEl) r.xEl.classList.toggle("on", !!r.on());
  if (r.pct && r.xEl) r.xEl.firstChild.style.width = r.pct() + "%";
}
function refreshRows() { for (var i = 0; i < ROWS.length; i++) updateRow(ROWS[i]); }

function activateRow(r) { if (r.go) r.go(); else if (r.adj) r.adj(1); }

function setHint() {
  var base = sFocus === "cats"
    ? "▲ ▼ categorias  ·  ▶ ou OK entra  ·  Voltar fecha"
    : "▲ ▼ escolhe  ·  ◀ ▶ muda o valor  ·  OK abre  ·  Voltar: categorias";
  $("sethint").textContent = sNoRead ? base + "  ·  A TV não deixou o launcher ler os ajustes; use “Todas as configurações”." : base;
}

// pinta o foco (categorias e linhas) - e o unico lugar que mexe nisso
function paintSettings() {
  var i, c = $("scats").children;
  for (i = 0; i < c.length; i++) {
    c[i].classList.toggle("focus", sFocus === "cats" && i === cIndex);
    c[i].classList.toggle("sel", i === cIndex);
  }
  var rows = curRows();
  for (i = 0; i < rows.length; i++) if (rows[i].el) rows[i].el.classList.toggle("focus", sFocus === "rows" && i === rIndex);
  setHint();
}

function rowEl(r, i) {
  var el = document.createElement("div"); el.className = "row"; el.style.setProperty("--ri", i);
  var ic = document.createElement("div"); ic.className = "ric"; ic.style.background = r.color; ic.innerHTML = SIC[r.ic];
  var lb = document.createElement("div"); lb.className = "rl"; lb.textContent = r.label;
  el.appendChild(ic); el.appendChild(lb);
  if (r.val) { r.vEl = document.createElement("div"); r.vEl.className = "rv"; el.appendChild(r.vEl); }
  r.xEl = document.createElement("div");
  if (r.on) r.xEl.className = "rx sw";
  else if (r.pct) { r.xEl.className = "rx sl"; r.xEl.innerHTML = "<i></i>"; }
  else { r.xEl.className = "rx chev"; r.xEl.textContent = "›"; }
  el.appendChild(r.xEl);
  r.el = el;
  el.addEventListener("mouseenter", function () { if (introDone && screen === "settings") { sFocus = "rows"; rIndex = i; paintSettings(); } });
  el.addEventListener("click", function () { if (introDone && screen === "settings") { sFocus = "rows"; rIndex = i; paintSettings(); activateRow(r); } });
  return el;
}

function renderPane() {
  var pane = $("spane"); pane.innerHTML = "";
  var h = document.createElement("div"); h.className = "shead"; h.textContent = CATS[cIndex].name; pane.appendChild(h);
  var card = document.createElement("div"); card.className = "sgroup"; pane.appendChild(card);
  curRows().forEach(function (r, i) { card.appendChild(rowEl(r, i)); });
  refreshRows(); paintSettings();
}
function selectCat(i) {
  if (i < 0 || i >= CATS.length || i === cIndex) return;
  cIndex = i; rIndex = 0;
  renderPane();
}

function buildSettings() {
  defineRows();
  var box = $("scats");
  CATS.forEach(function (c, i) {
    var el = document.createElement("div"); el.className = "row"; el.style.setProperty("--ri", i);
    var ic = document.createElement("div"); ic.className = "ric"; ic.style.background = c.color; ic.innerHTML = SIC[c.ic];
    var lb = document.createElement("div"); lb.className = "rl"; lb.textContent = c.name;
    el.appendChild(ic); el.appendChild(lb);
    el.addEventListener("mouseenter", function () { if (introDone && screen === "settings") { sFocus = "cats"; selectCat(i); paintSettings(); } });
    el.addEventListener("click", function () { if (introDone && screen === "settings") { sFocus = "rows"; selectCat(i); paintSettings(); } });
    box.appendChild(el);
  });
  $("sback").addEventListener("click", function () { if (introDone && screen === "settings") closeSettings(); });
  renderPane();
}

function openSettings() {
  if (screen !== "home") return;
  sFocus = "cats";
  push("settings");
  refreshSettings(); refreshRows(); paintSettings();
}
function closeSettings() { pop(); refreshFocus(); }

function settingsKey(k) {
  if (sFocus === "cats") {
    if (k === 38) selectCat(cIndex - 1);
    else if (k === 40) selectCat(cIndex + 1);
    else if (k === 39 || k === 13) { sFocus = "rows"; rIndex = 0; paintSettings(); }
    else if (k === 461 || k === 27) closeSettings();
    return;
  }
  var rows = curRows(), r = rows[rIndex];
  if (k === 38) { if (rIndex > 0) { rIndex--; paintSettings(); } }
  else if (k === 40) { if (rIndex < rows.length - 1) { rIndex++; paintSettings(); } }
  else if (k === 37) { if (r.adj) r.adj(-1); else { sFocus = "cats"; paintSettings(); } }
  else if (k === 39) { if (r.adj) r.adj(1); }
  else if (k === 13) activateRow(r);
  else if (k === 461 || k === 27) { sFocus = "cats"; paintSettings(); }
}

// ============================================================
// NOTICIAS REAIS + ATUALIZACAO PELO SITE
// Fonte 1: news.json do seu site (o GitHub monta a cada ~20 min com G1, ge, Tecnoblog...)
// Fonte 2 (reserva, nao precisa configurar nada): os mesmos jornais via rss2json.com
// A ultima lista fica guardada: aparece na hora ao abrir, mesmo sem internet.
// ============================================================
var newsInfo = { state: "loading", at: 0, from: "" };   // loading | ok | stale | offline
var autoUpd = true, updState = "";
var CATCOL = {
  "Brasil": ["#00e5ff", "#2f6bff"], "Mundo": ["#ff2fd0", "#7b2ff7"], "Esportes": ["#22d36b", "#0e8a45"],
  "Tecnologia": ["#ffa522", "#e0452f"], "Economia": ["#ffd23f", "#c77d00"], "Entretenimento": ["#ff5e7e", "#a1234d"]
};
function catColors(c) { return CATCOL[c] || ["#59c7ff", "#1e5fa8"]; }
function artBg(n) {
  var c = catColors(n.cat);
  return (n.img ? 'url("' + n.img.replace(/"/g, "%22") + '"),' : "") + "linear-gradient(135deg," + c[0] + "," + c[1] + ")";
}
function ago(ts) {
  if (!ts) return "";
  var m = Math.round((Date.now() - ts) / 60000);
  if (m < 2) return "agora";
  if (m < 60) return "há " + m + " min";
  var h = Math.round(m / 60);
  if (h < 24) return "há " + h + " h";
  var d = Math.round(h / 24);
  return "há " + d + (d === 1 ? " dia" : " dias");
}
function newsSub(n) { var a = ago(n.ts); return n.src + (a ? " · " + a : ""); }
function hhmm(ts) { var d = new Date(ts); return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2); }
function newsMsg() {
  if (newsInfo.state === "loading") return "Carregando notícias…";
  return "Sem notícias agora. Verifique a internet.";
}
function newsStatus() {
  if (newsInfo.state === "loading" && !NEWS.length) return "carregando…";
  if (!NEWS.length) return "sem conexão";
  var t = newsInfo.at ? "atualizado " + hhmm(newsInfo.at) : "";
  return NEWS.length + " matérias" + (t ? " · " + t : "") + (newsInfo.state === "stale" ? " (antigas)" : "");
}

function getJSON(url, ms, ok, fail) {
  var x = new XMLHttpRequest(), done = false;
  function bad() { if (!done) { done = true; if (fail) fail(); } }
  try {
    x.open("GET", url, true);
    x.timeout = ms;
    x.onerror = x.ontimeout = bad;
    x.onload = function () {
      var j = null;
      try { j = JSON.parse(x.responseText); } catch (e) {}
      if (x.status === 200 && j) { if (!done) { done = true; ok(j); } } else bad();
    };
    x.send();
  } catch (e) { bad(); }
}
function plain(h) {
  return String(h || "").replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&#39;|&#x27;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
}
function cleanItems(list) {
  var out = [], seen = {};
  (list || []).forEach(function (n) {
    if (!n || !n.t || !n.url) return;
    var k = n.t.toLowerCase().slice(0, 60);
    if (seen[k]) return; seen[k] = 1;
    out.push({ t: String(n.t), s: String(n.s || ""), src: String(n.src || ""), cat: String(n.cat || "Brasil"),
               img: n.img && /^https?:/i.test(n.img) ? String(n.img) : "", url: String(n.url), ts: +n.ts || 0 });
  });
  return out;
}
function mixByCat(items) {                     // intercala categorias: o comeco da lista fica variado
  var by = {}, order = [], out = [], more = true, i;
  items.sort(function (a, b) { return b.ts - a.ts; });
  items.forEach(function (n) { if (!by[n.cat]) { by[n.cat] = []; order.push(n.cat); } by[n.cat].push(n); });
  for (i = 0; more; i++) {
    more = false;
    order.forEach(function (c) { if (by[c][i]) { out.push(by[c][i]); more = true; } });
  }
  return out;
}
var RSS_FEEDS = [
  { cat: "Brasil", src: "G1", url: "https://g1.globo.com/rss/g1/" },
  { cat: "Esportes", src: "ge", url: "https://ge.globo.com/rss/ge/" },
  { cat: "Tecnologia", src: "Tecnoblog", url: "https://tecnoblog.net/feed/" },
  { cat: "Mundo", src: "G1 Mundo", url: "https://g1.globo.com/rss/g1/mundo/" },
  { cat: "Economia", src: "G1 Economia", url: "https://g1.globo.com/rss/g1/economia/" }
];
function viaRss2Json(done) {
  var all = [], left = RSS_FEEDS.length;
  function fin() { if (--left === 0) done(mixByCat(cleanItems(all))); }
  RSS_FEEDS.forEach(function (f) {
    getJSON("https://api.rss2json.com/v1/api.json?rss_url=" + encodeURIComponent(f.url), 12000, function (j) {
      (j.items || []).slice(0, 8).forEach(function (it) {
        var img = it.thumbnail || (it.enclosure && it.enclosure.link) || "";
        if (!/\.(jpe?g|png|webp)/i.test(img) && !/^https?:\/\/.*(glbimg|img|image|wp-content)/i.test(img)) img = "";
        if (!img) { var m = /<img[^>]+src=["']([^"']+)/i.exec((it.content || "") + (it.description || "")); if (m) img = m[1]; }
        var ts = Date.parse(String(it.pubDate || "").replace(" ", "T") + "Z") || 0;
        all.push({ t: plain(it.title), s: plain(it.description || it.content).slice(0, 280), src: f.src, cat: f.cat, img: img, url: it.link, ts: ts });
      });
      fin();
    }, fin);
  });
}
var newsBusy = false;
function newsChanged() {
  if (bnIdx > NEWS.length - 1) bnIdx = Math.max(0, NEWS.length - 1);
  if (newsIdx > NEWS.length - 1) newsIdx = Math.max(0, NEWS.length - 1);
  buildNewsPanel(); buildCyber(); refreshFocus();
  if (typeof refreshRows === "function") refreshRows();
}
function loadNews(manual) {
  if (newsBusy) return;
  newsBusy = true;
  if (manual) toast("Atualizando notícias…");
  function ok(items, from) {
    newsBusy = false;
    NEWS = items; newsInfo = { state: "ok", at: Date.now(), from: from };
    store("hz_news_cache", JSON.stringify({ at: newsInfo.at, items: items.slice(0, 40) }));
    newsChanged();
    if (manual) toast("Notícias atualizadas: " + items.length + " matérias");
  }
  function fail() {
    newsBusy = false;
    newsInfo.state = NEWS.length ? "stale" : "offline";
    newsChanged();
    if (manual) toast("Não consegui buscar as notícias. Confira a internet da TV.");
  }
  function fallback() { viaRss2Json(function (items) { if (items.length) ok(items, "rss"); else fail(); }); }
  var site = window.HZOTA ? HZOTA.site() : "";
  if (!site) { fallback(); return; }
  getJSON(site + "news.json?t=" + Date.now(), 12000, function (j) {
    var items = cleanItems(j.items);
    if (items.length) ok(items, "site"); else fallback();
  }, fallback);
}
(function () {                                 // mostra na hora o que ficou guardado
  try {
    var c = JSON.parse(recall("hz_news_cache", "null"));
    if (c && c.items && c.items.length) { NEWS = cleanItems(c.items); newsInfo = { state: "stale", at: c.at || 0, from: "cache" }; }
  } catch (e) {}
})();

// ---------- leitor de noticia ----------
var rIdx = 0;
function openReader(j) {
  if (!NEWS[j] || screen === "reader") return;
  rIdx = j; paintReader(); push("reader");
}
function paintReader() {
  var n = NEWS[rIdx];
  if (!n) return;
  $("rimg").style.backgroundImage = artBg(n);
  $("rcat").textContent = n.cat.toUpperCase();
  $("rtit").textContent = n.t;
  $("rsrc").textContent = newsSub(n) + "  ·  " + (rIdx + 1) + " de " + NEWS.length;
  $("rsum").textContent = n.s || "Sem resumo. Aperte OK para abrir a matéria.";
  $("rqr").innerHTML = HZQR.svg(n.url);
}
function readerKey(k) {
  var n = NEWS.length;
  if (k === 37) { rIdx = (rIdx + n - 1) % n; paintReader(); }
  else if (k === 39) { rIdx = (rIdx + 1) % n; paintReader(); }
  else if (k === 13) {
    luna("luna://com.webos.applicationManager/launch", { id: "com.webos.app.browser", params: { target: NEWS[rIdx].url } },
      function () { toast("Não deu para abrir o navegador da TV. Use o QR Code no celular."); });
  }
  else if (k === 461 || k === 27) {
    newsIdx = rIdx; bnIdx = rIdx;
    pop(); newsChanged();
  }
}

// ---------- campo de texto ----------
var promptCfg = null;
function openPrompt(cfg) {
  promptCfg = cfg;
  $("ptitle").textContent = cfg.title;
  $("phelp").textContent = cfg.help || "";
  var inp = $("pinput");
  inp.value = cfg.value || "";
  push("prompt");
  setTimeout(function () { try { inp.focus(); inp.select(); } catch (e) {} }, 150);
}
function promptKey(k) {
  var inp = $("pinput");
  if (k === 13) { var v = inp.value; inp.blur(); pop(); if (promptCfg && promptCfg.done) promptCfg.done(v); }
  else if (k === 461 || k === 27) { inp.blur(); pop(); }
}

// ---------- atualizacao ----------
function siteLabel() {
  var v = recall("hz_site", "") || window.HZ_SITE || "";
  return v ? v.replace(/^https?:\/\//, "").replace(/\.github\.io\//, " / ").replace(/\/$/, "") : "não definido";
}
function askSite() {
  openPrompt({
    title: "Endereço do site de atualizações",
    help: "Digite seu usuário do GitHub (ex.: enzo) ou usuário/repositório (ex.: enzo/horizon). O painel do site mostra exatamente o que digitar.",
    value: recall("hz_site", "") || window.HZ_SITE || "",
    done: function (v) {
      v = v.replace(/^\s+|\s+$/g, "");
      store("hz_site", v);
      updState = v ? "" : "defina o endereço do site";
      toast(v ? "Site salvo. Verificando…" : "Endereço apagado");
      refreshRows();
      if (v) { loadNews(); runCheck(true); }
    }
  });
}
function updText() {
  if (updState) return updState;
  if (window.HZOTA && HZOTA.ready) return "versão " + HZOTA.ready + " pronta";
  return "aperte OK para verificar";
}
function runCheck(manual, auto) {
  if (!window.HZOTA) { toast("Atualização pelo site não existe nesta versão."); return; }
  updState = "verificando…"; refreshRows();
  HZOTA.check(function (r) {
    if (r.state === "new") {
      updState = "versão " + r.version + " baixada";
      if (auto && Date.now() - bootAt < 40000 && screen === "home") { toast("Atualizando para a versão " + r.version + "…"); setTimeout(HZOTA.apply, 1400); }
      else toast("Versão " + r.version + " baixada. Config. › Atualização › Aplicar versão baixada.");
    }
    else if (r.state === "same") { updState = "em dia (" + HZOTA.running + ")"; if (manual) toast("Você já está na versão mais nova."); }
    else if (r.state === "nosite") { updState = "defina o endereço do site"; if (manual) toast("Defina o endereço do site primeiro."); }
    else if (r.state === "bad") { updState = "versão " + r.version + " deu erro e foi ignorada"; if (manual) toast(updState); }
    else { updState = "sem conexão com o site"; if (manual) toast("Não consegui falar com o site. Confira o endereço e a internet."); }
    refreshRows();
  });
}
function toggleAutoUpd() {
  autoUpd = !autoUpd;
  store("hz_autoupd", autoUpd ? "1" : "0");
  refreshRows();
}

// ============================================================
// INICIO
// ============================================================
savedStyle = recall("hz_style", "glass");
if (!validStyle(savedStyle)) savedStyle = "glass";
savedLife = recall("hz_life", "basic");
if (!LIFE[savedLife]) savedLife = "basic";
introOn = recall("hz_intro", "1") === "1";
introSnd = recall("hz_introsnd", "1") === "1";
clock24 = recall("hz_h24", "1") === "1";
showNews = recall("hz_news", "1") === "1";
autoUpd = recall("hz_autoupd", "1") === "1";
theme = recall("hz_theme", "default") === "dark" ? "dark" : "default";
try { iconCache = JSON.parse(recall("hz_icons", "{}")) || {}; } catch (e) { iconCache = {}; }
prepAudio();

// atalhos so para testes: ?skip  ?style=aero  ?life=cyber  ?theme=dark
var qs = location.search;
var m = qs.match(/style=([a-z0-9]+)/);
if (m && validStyle(m[1])) savedStyle = m[1];
var ml = qs.match(/life=([a-z]+)/);
if (ml && LIFE[ml[1]]) savedLife = ml[1];
life = savedLife;
document.documentElement.setAttribute("data-life", life);
loadLayout();
applyStyle(savedStyle);
if (qs.indexOf("theme=dark") !== -1) theme = "dark";
applyTheme();

perf = recall("hz_perf", "normal") === "lite" ? "lite" : "normal";
applyPerf();

buildIntroLetters();
TOOLS.forEach(function (t) { wireHdr($(t.id)); });
buildNewsPanel();
applyNews();                 // monta abas e cartoes do Cyber e liga/desliga as noticias
buildGrid();
// brilhos que flutuam no fundo (animados so por CSS)
(function () {
  var box = $("sparks"), seed = 7, n = 16;
  function rnd() { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; }
  for (var i = 0; i < n; i++) {
    var d = document.createElement("i"), z = 8 + Math.round(rnd() * 16);
    d.className = "spk";
    d.style.cssText = "left:" + Math.round(rnd() * 96) + "%;top:" + Math.round(18 + rnd() * 80) + "%;width:" + z + "px;height:" + z + "px;" +
      "animation-duration:" + (7 + rnd() * 7).toFixed(1) + "s;animation-delay:-" + (rnd() * 12).toFixed(1) + "s";
    box.appendChild(d);
  }
})();

buildSettings();
tick();
setInterval(tick, 30000);

if (qs.indexOf("skip") !== -1 || !introOn) {
  endIntro();
} else {
  startIntro();
}
loadIcons();

// notícias: busca ao abrir e a cada 20 min; atualização do launcher: confere ao abrir
loadNews();
setInterval(loadNews, 20 * 60 * 1000);
setTimeout(function () { if (autoUpd && window.HZOTA && HZOTA.site()) runCheck(false, true); }, 3000);
if (window.HZOTA) HZOTA.confirm();      // avisa a rede de seguranca que esta versao subiu bem
