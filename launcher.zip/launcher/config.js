/* Endereco do seu site de atualizacoes (opcional aqui: tambem da para definir na TV em
   Config. > Atualizacao > Endereco do site). Exemplos: "enzo", "enzo/horizon" */
window.HZ_SITE = "";
