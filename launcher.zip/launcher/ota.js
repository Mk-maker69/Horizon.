/* Horizon TV - atualizacao pelo ar (OTA).
   Este arquivo fica DENTRO do app (TV/APK) e quase nunca muda.
   Ele decide qual versao do launcher roda: a que veio instalada ou uma mais nova
   baixada do seu site (guardada em localStorage). Se a versao nova der erro,
   volta sozinho para a anterior. */
(function () {
  var BUNDLED = "2.1.0";                       // (o build.mjs atualiza esta linha)
  var H = window.HZOTA = { bundled: BUNDLED, running: BUNDLED, source: "app", ok: false, ready: null };

  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function set(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
  function del(k) { try { localStorage.removeItem(k); } catch (e) {} }
  function cmp(a, b) {
    a = String(a || "0").split("."); b = String(b || "0").split(".");
    for (var i = 0; i < 3; i++) { var x = parseInt(a[i], 10) || 0, y = parseInt(b[i], 10) || 0; if (x !== y) return x > y ? 1 : -1; }
    return 0;
  }
  H.cmp = cmp;
  H.confirm = function () { H.ok = true; del("hz_ota_pending"); };   // o app chama quando terminou de subir

  // endereco do site: "usuario", "usuario/repo" ou URL completa
  H.site = function () {
    var v = (get("hz_site") || window.HZ_SITE || "").replace(/^\s+|\s+$/g, "");
    if (!v) return "";
    if (/^https?:\/\//i.test(v)) return v.replace(/\/*$/, "/");
    var p = v.split("/");
    return "https://" + p[0].toLowerCase() + ".github.io/" + (p[1] || "horizon") + "/";
  };

  function rollback(why) {
    var c = null; try { c = JSON.parse(get("hz_ota")); } catch (e) {}
    if (c && c.version) set("hz_ota_bad", c.version);
    del("hz_ota"); del("hz_ota_pending");
    try { sessionStorage.setItem("hz_rb", why || "1"); } catch (e) {}
  }

  // ---- 3) procurar versao nova no site ----
  // cb({state: "nosite"|"offline"|"bad"|"same"|"new", version, notes})
  H.check = function (cb) {
    var base = H.site();
    if (!base) { cb({ state: "nosite" }); return; }
    var x = new XMLHttpRequest(), done = false;
    function end(r) { if (!done) { done = true; cb(r); } }
    x.open("GET", base + "app/bundle.json?t=" + Date.now(), true);
    x.timeout = 12000;
    x.onerror = x.ontimeout = function () { end({ state: "offline" }); };
    x.onload = function () {
      var b = null;
      try { b = JSON.parse(x.responseText); } catch (e) {}
      if (x.status !== 200 || !b || !b.version || !b.js || !b.body) { end({ state: "offline" }); return; }
      H.remote = b.version;
      if (cmp(b.version, H.running) <= 0) { end({ state: "same", version: b.version }); return; }
      if (b.version === get("hz_ota_bad")) { end({ state: "bad", version: b.version }); return; }
      if (!set("hz_ota", JSON.stringify(b)) || get("hz_ota") === null) { end({ state: "offline", why: "sem espaco" }); return; }
      H.ready = b.version;
      end({ state: "new", version: b.version, notes: b.notes || "" });
    };
    x.send();
  };
  H.apply = function () { location.reload(); };

  function boot() {
    // ---- 1) escolher o que rodar ----
    var cache = null;
    try { cache = JSON.parse(get("hz_ota")); } catch (e) { cache = null; }
    if (cache && get("hz_ota_pending") === cache.version) {      // a ultima abertura com esta versao nunca terminou
      rollback("pending"); cache = null;
    }
    var useOta = !!(cache && cache.js && cache.body && cmp(cache.version, BUNDLED) > 0);
    if (cache && !useOta) { del("hz_ota"); }                      // o app instalado ja e igual ou mais novo

    function addScript(src, text) {
      var s = document.createElement("script");
      if (src) s.src = src; else s.text = text;
      document.body.appendChild(s);
    }

    // ---- 2) rede de seguranca: se a versao nova nao confirmar que subiu, volta para a antiga ----
    if (useOta) {
      window.addEventListener("error", function () {
        if (H.ok || sessionStorage.getItem("hz_rb")) return;
        rollback("error"); location.reload();
      });
      setTimeout(function () {
        if (H.ok || sessionStorage.getItem("hz_rb")) return;
        rollback("timeout"); location.reload();
      }, 6000);
    }



    if (useOta) {
      set("hz_ota_pending", cache.version);
      H.running = cache.version; H.source = "site";
      var link = document.querySelector('link[rel="stylesheet"]');
      if (link && link.parentNode) link.parentNode.removeChild(link);
      var st = document.createElement("style"); st.id = "hz-ota-css"; st.appendChild(document.createTextNode(cache.css || ""));
      document.head.appendChild(st);
      document.body.innerHTML = cache.body;
      try { addScript(null, cache.js); }
      catch (e) { rollback("throw"); location.reload(); return; }
    } else {
      addScript("app.js");
    }

  }
  boot();
})();
